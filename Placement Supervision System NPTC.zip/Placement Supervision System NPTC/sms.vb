﻿Imports System.Web
Imports System.IO
Imports System.Net
Imports System.Text
Imports System.Resources
Imports System.Data.SqlClient

Public Class sms
    Dim con As SqlConnection
    Dim com As SqlCommand
    Dim ada As SqlDataAdapter
    Dim ds As DataSet
    Dim dv As DataView
    Dim drv As DataRowView
    Dim rd As SqlDataReader
    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click
        Dim apikey = "K9LsAj124SM-1QsQE6mZ6wD5xh4fLKDUH9orm17iTZ"
        Dim message = RichTextBox1.Text
        Dim numbers = TextBox2.Text
        Dim strGet As String
        Dim sendername = ComboBox1.Text
        Dim url As String = "https://api.textlocal.in/send/?"

        strGet = url + "apikey=" + apikey +
        "&numbers=" + numbers +
        "&message=" + WebUtility.UrlEncode(message) +
        "&sendername=" + sendername

        Dim webClient As New System.Net.WebClient
        Dim result As String = webClient.DownloadString(strGet)
        MessageBox.Show(result, "Information", MessageBoxButtons.OK, MessageBoxIcon.Information)
        'Console.WriteLine(result)
        'Return result

    End Sub

   
    Private Sub sms_Load(sender As Object, e As EventArgs) Handles MyBase.Load


        con = New SqlConnection
        com = New SqlCommand
        con.ConnectionString = "Data Source=VENGATESH-PC;Initial Catalog=igi;User ID=sa;Password=aa"
        con.Open()
        com.Connection = con
        com.CommandText = "select roll_no from insert1"
        rd = com.ExecuteReader
        While rd.Read
            ComboBox1.Items.Add(rd.GetString(0))
        End While
        rd.Close()
    End Sub

    Private Sub Label1_Click(sender As Object, e As EventArgs) Handles Label1.Click

    End Sub

    Private Sub ComboBox1_SelectedIndexChanged(sender As Object, e As EventArgs) Handles ComboBox1.SelectedIndexChanged
        con = New SqlConnection
        com = New SqlCommand
        con.ConnectionString = "Data Source=VENGATESH-PC;Initial Catalog=igi;User ID=sa;Password=aa"
        con.Open()
        com.Connection = con
        com.CommandText = "select phone_no from insert1 where roll_no='" & ComboBox1.Text & "'"
        rd = com.ExecuteReader
        While rd.Read
            TextBox2.Text = rd.GetString(0)
        End While
        rd.Close()
    End Sub
    Private Sub INSERTToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles INSERTToolStripMenuItem.Click
        Insert1.Show()
        Me.Close()
    End Sub

    Private Sub UPDATEToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles UPDATEToolStripMenuItem.Click
        Update1.Show()
        Me.Close()
    End Sub

    Private Sub DELETEToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles DELETEToolStripMenuItem.Click
        Delete1.Show()
        Me.Close()
    End Sub

    Private Sub VIEWToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles VIEWToolStripMenuItem.Click
        Selectview1.Show()
        Me.Close()
    End Sub

    Private Sub LogOutToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles LogOutToolStripMenuItem.Click
        welcome.Show()
        Me.Close()
    End Sub

    Private Sub INSERTToolStripMenuItem1_Click(sender As Object, e As EventArgs) Handles INSERTToolStripMenuItem1.Click
        Interinsert1.Show()
        Me.Close()
    End Sub

    Private Sub UPDATEToolStripMenuItem1_Click(sender As Object, e As EventArgs) Handles UPDATEToolStripMenuItem1.Click
        Interupdate1.Show()
        Me.Close()
    End Sub

    Private Sub DELETEToolStripMenuItem1_Click(sender As Object, e As EventArgs) Handles DELETEToolStripMenuItem1.Click
        InterDelete1.Show()
        Me.Close()
    End Sub

    Private Sub INSERTToolStripMenuItem2_Click(sender As Object, e As EventArgs) Handles INSERTToolStripMenuItem2.Click
        pinsert1.Show()
        Me.Close()
    End Sub

    Private Sub UPDATEToolStripMenuItem2_Click(sender As Object, e As EventArgs) Handles UPDATEToolStripMenuItem2.Click
        pupdate1.Show()
        Me.Close()
    End Sub

    Private Sub DELETEToolStripMenuItem2_Click(sender As Object, e As EventArgs) Handles DELETEToolStripMenuItem2.Click
        pdelete1.Show()
        Me.Close()
    End Sub

    Private Sub VIEWToolStripMenuItem2_Click(sender As Object, e As EventArgs) Handles VIEWToolStripMenuItem2.Click
        pselectview.Show()
        Me.Close()
    End Sub

    Private Sub INSERTToolStripMenuItem3_Click(sender As Object, e As EventArgs) Handles INSERTToolStripMenuItem3.Click
        Compinsert1.Show()
        Me.Close()
    End Sub

    Private Sub UPDATEToolStripMenuItem3_Click(sender As Object, e As EventArgs) Handles UPDATEToolStripMenuItem3.Click
        Compupdate1.Show()
        Me.Close()
    End Sub

    Private Sub DELETEToolStripMenuItem3_Click(sender As Object, e As EventArgs) Handles DELETEToolStripMenuItem3.Click
        compdelete1.Show()
        Me.Close()
    End Sub

    Private Sub VIEWToolStripMenuItem3_Click(sender As Object, e As EventArgs) Handles VIEWToolStripMenuItem3.Click
        Compselectview.Show()
        Me.Close()
    End Sub

    Private Sub AddANewUserToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles AddANewUserToolStripMenuItem.Click
        registration_form.Show()
        Me.Close()
    End Sub

    Private Sub EXITToolStripMenuItem1_Click(sender As Object, e As EventArgs) Handles EXITToolStripMenuItem1.Click
        Me.Close()
    End Sub
    Private Sub MAILTHEDATASToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles MAILTHEDATASToolStripMenuItem.Click
        mailmodule1.Show()
        Me.Close()
    End Sub

    Private Sub DEPATMENTREPORTToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles DEPATMENTREPORTToolStripMenuItem.Click
        DeptReport.Show()
        Me.Close()
    End Sub

    Private Sub ChangePasswordToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles ChangePasswordToolStripMenuItem.Click
        change_password.Show()
        Me.Close()
    End Sub

    Private Sub Button2_Click(sender As Object, e As EventArgs) Handles Button2.Click
        report.Show()
        Me.Close()
    End Sub
End Class