﻿Imports System.Data.SqlClient
Imports System.Net.Mail
Public Class mailmodule1
    Dim con As SqlConnection
    Dim com As SqlCommand
    Dim rd As SqlDataReader
    Dim dv As DataView
    Dim drv As DataRowView
    Dim ds As DataSet
    Dim ada As SqlDataAdapter
    Private Sub Button2_Click(sender As Object, e As EventArgs)
        welcome.Show()
        Me.Close()
    End Sub

    Private Sub Button3_Click(sender As Object, e As EventArgs) Handles Button3.Click
        report.Show()
        Me.Close()
    End Sub

    Public Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click
        Dim smtp_server As New SmtpClient
        Dim gmail As New MailMessage

        smtp_server.UseDefaultCredentials = False
        smtp_server.Credentials = New Net.NetworkCredential("pssprojectnpt@gmail.com", "pssproject2020")
        smtp_server.Port = 587
        smtp_server.EnableSsl = True
        smtp_server.Host = "smtp.gmail.com"
        gmail = New MailMessage
        gmail.From = New MailAddress("pssprojectnpt@gmail.com")
        gmail.To.Add(TextBox1.Text)
        gmail.IsBodyHtml = True
        gmail.Subject = TextBox2.Text
        gmail.Body = RichTextBox1.Text()
        smtp_server.Send(gmail)
        MsgBox("Mail is sent to the user")

    End Sub

    Private Sub ComboBox1_SelectedIndexChanged(sender As Object, e As EventArgs) Handles ComboBox1.SelectedIndexChanged
        con = New SqlConnection
        com = New SqlCommand
        con.ConnectionString = "Data Source=VENGATESH-PC;Initial Catalog=igi;User ID=sa;Password=aa"
        con.Open()
        com.Connection = con
        com.CommandText = "select email from insert1 where roll_no='" & ComboBox1.Text & "'"
        rd = com.ExecuteReader
        While rd.Read
            TextBox1.Text = rd.GetString(0)
        End While
        rd.Close()
    End Sub

    Private Sub INSERTToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles INSERTToolStripMenuItem.Click
        Insert1.Show()
        Me.Close()
    End Sub

    Private Sub UPDATEToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles UPDATEToolStripMenuItem.Click
        Update1.Show()
        Me.Close()
    End Sub

    Private Sub DELETEToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles DELETEToolStripMenuItem.Click
        Delete1.Show()
        Me.Close()
    End Sub

    Private Sub VIEWToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles VIEWToolStripMenuItem.Click
        Selectview1.Show()
        Me.Close()
    End Sub

    Private Sub LogOutToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles LogOutToolStripMenuItem.Click
        welcome.Show()
        Me.Close()
    End Sub

    Private Sub INSERTToolStripMenuItem1_Click(sender As Object, e As EventArgs) Handles INSERTToolStripMenuItem1.Click
        Interinsert1.Show()
        Me.Close()
    End Sub

    Private Sub UPDATEToolStripMenuItem1_Click(sender As Object, e As EventArgs) Handles UPDATEToolStripMenuItem1.Click
        Interupdate1.Show()
        Me.Close()
    End Sub

    Private Sub DELETEToolStripMenuItem1_Click(sender As Object, e As EventArgs) Handles DELETEToolStripMenuItem1.Click
        InterDelete1.Show()
        Me.Close()
    End Sub

    Private Sub INSERTToolStripMenuItem2_Click(sender As Object, e As EventArgs) Handles INSERTToolStripMenuItem2.Click
        pinsert1.Show()
        Me.Close()
    End Sub

    Private Sub UPDATEToolStripMenuItem2_Click(sender As Object, e As EventArgs) Handles UPDATEToolStripMenuItem2.Click
        pupdate1.Show()
        Me.Close()
    End Sub

    Private Sub DELETEToolStripMenuItem2_Click(sender As Object, e As EventArgs) Handles DELETEToolStripMenuItem2.Click
        pdelete1.Show()
        Me.Close()
    End Sub

    Private Sub VIEWToolStripMenuItem2_Click(sender As Object, e As EventArgs) Handles VIEWToolStripMenuItem2.Click
        pselectview.Show()
        Me.Close()
    End Sub

    Private Sub INSERTToolStripMenuItem3_Click(sender As Object, e As EventArgs) Handles INSERTToolStripMenuItem3.Click
        Compinsert1.Show()
        Me.Close()
    End Sub

    Private Sub UPDATEToolStripMenuItem3_Click(sender As Object, e As EventArgs) Handles UPDATEToolStripMenuItem3.Click
        Compupdate1.Show()
        Me.Close()
    End Sub

    Private Sub DELETEToolStripMenuItem3_Click(sender As Object, e As EventArgs) Handles DELETEToolStripMenuItem3.Click
        compdelete1.Show()
        Me.Close()
    End Sub

    Private Sub VIEWToolStripMenuItem3_Click(sender As Object, e As EventArgs) Handles VIEWToolStripMenuItem3.Click
        Compselectview.Show()
        Me.Close()
    End Sub

    Private Sub AddANewUserToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles AddANewUserToolStripMenuItem.Click
        registration_form.Show()
        Me.Close()
    End Sub

    Private Sub EXITToolStripMenuItem1_Click(sender As Object, e As EventArgs) Handles EXITToolStripMenuItem1.Click
        Me.Close()
    End Sub
   
    Private Sub DEPATMENTREPORTToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles DEPATMENTREPORTToolStripMenuItem.Click
        DeptReport.Show()
        Me.Close()
    End Sub

   

    Private Sub ChangePasswordToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles ChangePasswordToolStripMenuItem.Click
        change_password.Show()
        Me.Close()
    End Sub

  
    Private Sub mailmodule1_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        con = New SqlConnection
        com = New SqlCommand
        Dim gmail As New MailMessage
        con.ConnectionString = "Data Source=VENGATESH-PC;Initial Catalog=igi;User ID=sa;Password=aa"
        con.Open()
        com.Connection = con
        com.CommandText = "select roll_no from insert1"
        rd = com.ExecuteReader
        While rd.Read
            ComboBox1.Items.Add(rd.GetString(0))
        End While
        rd.Close()

    End Sub

    Private Sub SENDTHESMSToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles SENDTHESMSToolStripMenuItem.Click
        sms.Show()
        Me.Close()
    End Sub
End Class