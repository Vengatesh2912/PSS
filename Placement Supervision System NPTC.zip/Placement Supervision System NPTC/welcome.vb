﻿Public Class welcome
    Dim cuRWidth As Integer = Me.Width
    Dim cuRHeight As Integer = Me.Height
    Private Sub welcome_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        
    End Sub


    Private Sub Button1_Click_1(sender As Object, e As EventArgs) Handles Button1.Click
        LOGIN.Show()
        Me.Close()
    End Sub

    Private Sub welcome_Resize(sender As Object, e As EventArgs) Handles Me.Resize
        Dim ratioheight As Double = (Me.Height - cuRHeight) / cuRHeight
        Dim ratiowidth As Double = (Me.Width - cuRWidth) / cuRWidth
        For Each Ctrl As Control In Controls
            Ctrl.Width += Ctrl.Width * ratiowidth
            Ctrl.Left += Ctrl.Left * ratiowidth
            Ctrl.Top += Ctrl.Top * ratioheight
            Ctrl.Height += Ctrl.Height * ratioheight
        Next
        cuRHeight = Me.Height
        cuRWidth = Me.Width
    End Sub
End Class
