﻿
Imports System.Data.SqlClient
Public Class OverReport
    Dim con As SqlConnection
    Dim com As SqlCommand
    Dim ada As SqlDataAdapter
    Dim ds As DataSet
    Dim dv As DataView
    Dim drv As DataRowView
    Dim rd As SqlDataReader
    Dim table As DataTable
    Dim i As Integer

    Private Sub Button2_Click(sender As Object, e As EventArgs)
        welcome.Show()
        Me.Close()
    End Sub

    Private Sub Button3_Click(sender As Object, e As EventArgs) Handles Button3.Click
        report.Show()
        Me.Close()
    End Sub

    Private Sub OverReport_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        'TODO: This line of code loads data into the 'IgiDataSet4.insert1' table. You can move, or remove it, as needed.
        Me.Insert1TableAdapter.Fill(Me.IgiDataSet4.insert1)
      
        con = New SqlConnection
        com = New SqlCommand
        con.ConnectionString = "Data Source=VENGATESH-PC;Initial Catalog=igi;User ID=sa;Password=aa"
        con.Open()
        com.Connection = con

        ada = New SqlDataAdapter("select *from insert1", con)
        ds = New DataSet
        ada.Fill(ds, "insert1")
        ada.Fill(table)
        dv = New DataView(ds.Tables("insert1"))
        drv = dv(0)
        DataGridView1.Columns(0).DefaultCellStyle.Font = New Font("times new roman", 9, FontStyle.Regular)
        DataGridView1.Columns(1).DefaultCellStyle.Font = New Font("times new roman", 9, FontStyle.Regular)
        DataGridView1.Columns(2).DefaultCellStyle.Font = New Font("times new roman", 9, FontStyle.Regular)
        DataGridView1.Columns(3).DefaultCellStyle.Font = New Font("times new roman", 9, FontStyle.Regular)
        DataGridView1.Columns(4).DefaultCellStyle.Font = New Font("times new roman", 9, FontStyle.Regular)
        DataGridView1.Columns(5).DefaultCellStyle.Font = New Font("times new roman", 9, FontStyle.Regular)
        DataGridView1.Columns(6).DefaultCellStyle.Font = New Font("times new roman", 9, FontStyle.Regular)
        DataGridView1.Columns(7).DefaultCellStyle.Font = New Font("times new roman", 9, FontStyle.Regular)
        DataGridView1.Columns(8).DefaultCellStyle.Font = New Font("times new roman", 9, FontStyle.Regular)
        DataGridView1.Columns(9).DefaultCellStyle.Font = New Font("times new roman", 9, FontStyle.Regular)
        DataGridView1.Columns(10).DefaultCellStyle.Font = New Font("times new roman", 9, FontStyle.Regular)
        DataGridView1.Columns(11).DefaultCellStyle.Font = New Font("times new roman", 9, FontStyle.Regular)
        DataGridView1.Columns(0).HeaderText = "name"
        DataGridView1.Columns(1).HeaderText = "address"
        DataGridView1.Columns(2).HeaderText = "phone_no"
        DataGridView1.Columns(3).HeaderText = "email"
        DataGridView1.Columns(4).HeaderText = "age"
        DataGridView1.Columns(5).HeaderText = "roll_no"
        DataGridView1.Columns(6).HeaderText = "department"
        DataGridView1.Columns(7).HeaderText = "year"
        DataGridView1.Columns(8).HeaderText = "SSLC"
        DataGridView1.Columns(9).HeaderText = "Diploma"
        DataGridView1.Columns(10).HeaderText = "Placed_company"
        DataGridView1.Columns(11).HeaderText = "placed_or_not"
    End Sub

    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click
        com = con.CreateCommand()
        com.CommandType = CommandType.Text
        com.CommandText = "select * from insert1 where roll_no='" + TextBox1.Text + "' "
        com.ExecuteNonQuery()
        Dim dt As New DataTable()
        Dim da As New SqlDataAdapter(com)
        da.Fill(dt)
        DataGridView1.DataSource = dt
    End Sub
    Private Sub DataGridView1_CellContentClick(sender As Object, e As DataGridViewCellEventArgs)

    End Sub

    Private Sub DataGridView1_CellClick(sender As Object, e As DataGridViewCellEventArgs) Handles DataGridView1.CellClick
        Try
            If con.State = ConnectionState.Open Then
                con.Close()
            End If
            con.Open()
            i = Convert.ToInt32(DataGridView1.SelectedCells.Item(0).Value.ToString())
            com = con.CreateCommand()
            com.CommandType = CommandType.Text
            com.CommandText = "select roll_no from insert1 where name=" & i & ""
            com.ExecuteNonQuery()
            Dim dt As New DataTable()
            Dim da As New SqlDataAdapter(com)
            da.Fill(dt)
            Dim dr As SqlClient.SqlDataReader
            dr = com.ExecuteReader(CommandBehavior.CloseConnection)
            While dr.Read
                TextBox1.Text = dr.GetString(0).ToString()
            End While
        Catch ex As Exception
        End Try
    End Sub

    Private Sub ChangePasswordToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles ChangePasswordToolStripMenuItem.Click
        change_password.Show()
        Me.Close()
    End Sub

    Private Sub Button2_Click_1(sender As Object, e As EventArgs) Handles Button2.Click
        SaveFileDialog1.ShowDialog()
        TextBox2.Text = SaveFileDialog1.FileName

    End Sub

    Private Sub Button4_Click(sender As Object, e As EventArgs) Handles Button4.Click
        Dim xlApp As Microsoft.Office.Interop.Excel.Application
        Dim xlWorkBook As Microsoft.Office.Interop.Excel.Workbook
        Dim xlWorkSheet As Microsoft.Office.Interop.Excel.Worksheet
        Dim misValue As Object = System.Reflection.Missing.Value
        Dim i As Integer
        Dim j As Integer
        xlApp = New Microsoft.Office.Interop.Excel.Application
        xlWorkBook = xlApp.Workbooks.Add(misValue)
        xlWorkSheet = xlWorkBook.Sheets("sheet1")
        For i = 0 To DataGridView1.RowCount - 2
            For j = 0 To DataGridView1.ColumnCount - 1
                For k As Integer = 1 To DataGridView1.Columns.Count
                    xlWorkSheet.Cells(1, k) = DataGridView1.Columns(k - 1).HeaderText
                    xlWorkSheet.Cells(i + 2, j + 1) = DataGridView1(j, i).Value.ToString()
                Next
            Next
        Next
        xlWorkSheet.SaveAs("" & TextBox2.Text & ".xlsx")
        xlWorkBook.Close()
        xlApp.Quit()
        releaseObject(xlApp)
        releaseObject(xlWorkBook)
        releaseObject(xlWorkSheet)
        MsgBox("The records are inserted successfully!!!. View the File at this location '" & TextBox2.Text & "' ")

    End Sub

    Private Sub releaseObject(ByVal obj As Object)
        Try
            System.Runtime.InteropServices.Marshal.ReleaseComObject(obj)
            obj = Nothing
        Catch ex As Exception
            obj = Nothing
        Finally
            GC.Collect()
        End Try
    End Sub

    Private Sub TextBox2_TextChanged(sender As Object, e As EventArgs) Handles TextBox2.TextChanged

    End Sub
End Class