﻿Imports System.Data.SqlClient
Public Class deptupdate1
    Dim con As SqlConnection
    Dim com As SqlCommand
    Dim rd As SqlDataReader
    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click
        If ComboBox1.SelectedItem = "" Then
            MsgBox("Please select any roll_no")
        Else
            deptupdate2.Show()
            Me.Close()
        End If
    End Sub

    Private Sub deptupdate1_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        con = New SqlConnection
        com = New SqlCommand
        con.ConnectionString = "Data Source=VENGATESH-PC;Initial Catalog=igi;User ID=sa;Password=aa"
        con.Open()
        com.Connection = con
        com.CommandText = "select roll_no from insert1"
        rd = com.ExecuteReader
        While rd.Read
            ComboBox1.Items.Add(rd.GetString(0))
        End While
        rd.Close()
    End Sub

    Private Sub ChangePasswordToolStripMenuItem_Click(sender As Object, e As EventArgs)
        change_password.Show()
        Me.Close()
    End Sub

    Private Sub AddANewUserToolStripMenuItem_Click(sender As Object, e As EventArgs)
        registration_form.Show()
        Me.Close()
    End Sub

    Private Sub LogOutToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles LogOutToolStripMenuItem.Click
        LOGIN.Show()
        Me.Close()
    End Sub

    Private Sub EXITToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles EXITToolStripMenuItem.Click
        Me.Close()
    End Sub

    Private Sub INSERTToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles INSERTToolStripMenuItem.Click
        deptinsert.Show()
        Me.Close()
    End Sub
    Private Sub DELETEToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles DELETEToolStripMenuItem.Click
        deptdelete.Show()
        Me.Close()
    End Sub

    Private Sub VIEWToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles VIEWToolStripMenuItem.Click
        deptselectview.Show()
        Me.Close()
    End Sub

    Private Sub Button3_Click(sender As Object, e As EventArgs) Handles Button3.Click
        deptmenu.Show()
        Me.Close()
    End Sub
End Class