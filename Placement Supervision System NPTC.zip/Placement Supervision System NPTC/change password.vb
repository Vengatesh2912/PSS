﻿Imports System.Data.SqlClient
Public Class change_password
    Dim con As SqlConnection
    Dim com As SqlCommand
    Dim rd As SqlDataReader
    Dim ada As SqlDataAdapter
    Dim dv As DataView
    Dim drv As DataRowView
    Dim ds As DataSet
    Dim cuRWidth As Integer = Me.Width
    Dim cuRHeight As Integer = Me.Height
    Private Sub change_password_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        con = New SqlConnection
        com = New SqlCommand
        con.ConnectionString = "Data Source=VENGATESH-PC;Initial Catalog=igi;User ID=sa;Password=aa"
        con.Open()
        com.Connection = con
        com.CommandText = "select username from login"
        rd = com.ExecuteReader
        While rd.Read
            ComboBox2.Items.Add(rd.GetString(0))
        End While
        rd.Close()
    End Sub

    Private Sub change_password_Resize(sender As Object, e As EventArgs) Handles Me.Resize
        Dim ratioheight As Double = (Me.Height - cuRHeight) / cuRHeight
        Dim ratiowidth As Double = (Me.Width - cuRWidth) / cuRWidth
        For Each Ctrl As Control In Controls
            Ctrl.Width += Ctrl.Width * ratiowidth
            Ctrl.Left += Ctrl.Left * ratiowidth
            Ctrl.Top += Ctrl.Top * ratioheight
            Ctrl.Height += Ctrl.Height * ratioheight
        Next
        cuRHeight = Me.Height
        cuRWidth = Me.Width
    End Sub

    Private Sub Button2_Click(sender As Object, e As EventArgs)
        welcome.Show()
        Me.Close()
    End Sub

    Private Sub ComboBox2_SelectedIndexChanged(sender As Object, e As EventArgs)
        con = New SqlConnection
        com = New SqlCommand
        con.ConnectionString = "Data Source=VENGATESH-PC;Initial Catalog=igi;User ID=sa;Password=aa"
        con.Open()
        com.Connection = con
        com.CommandText = "select password from login where username='" & ComboBox2.Text & "'"
        rd = com.ExecuteReader
        While rd.Read
            password.Text = rd.GetString(0)
        End While
        rd.Close()
    End Sub

    Private Sub Button1_Click_1(sender As Object, e As EventArgs) Handles Button1.Click
        com.CommandText = "update login set usertype='" & ComboBox1.SelectedItem & "',username='" & ComboBox2.SelectedItem & "',password='" & password.Text & "' where username= '" & ComboBox2.SelectedItem & "'"
        com.Connection = con
        com.ExecuteNonQuery()

        If ComboBox1.SelectedItem = "" Then
            MsgBox("Please give any UserType")
        ElseIf ComboBox2.SelectedItem = "" Then
            MsgBox("Please select any UserName ")
        ElseIf password.Text = "" Then
            MsgBox("Please give any password")

        Else
            MsgBox("Your Password changed Successfully!!!!")
            ComboBox1.ResetText()
            ComboBox2.ResetText()
            password.Clear()
            LOGIN.Show()
            Me.Close()
        End If
    End Sub

    Private Sub Button2_Click_1(sender As Object, e As EventArgs) Handles Button2.Click
        LOGIN.Show()
        Me.Close()

    End Sub

    Private Sub Label1_Click(sender As Object, e As EventArgs) Handles Label1.Click

    End Sub
End Class