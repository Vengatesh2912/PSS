﻿Imports System.Data.SqlClient
Public Class registration_form
    Dim con As SqlConnection
    Dim com As SqlCommand
    Dim rd As SqlDataReader
    Dim cuRWidth As Integer = Me.Width
    Dim cuRHeight As Integer = Me.Height
    Private Sub registration_form_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        Dim nam As String
        con = New SqlConnection
        com = New SqlCommand
        con.ConnectionString = "Data Source=VENGATESH-PC;Initial Catalog=igi;User ID=sa;Password=aa"
        con.Open()
        com.Connection = con
        nam = ComboBox1.SelectedItem
    End Sub

    Private Sub registration_form_Resize(sender As Object, e As EventArgs) Handles Me.Resize
        Dim ratioheight As Double = (Me.Height - cuRHeight) / cuRHeight
        Dim ratiowidth As Double = (Me.Width - cuRWidth) / cuRWidth
        For Each Ctrl As Control In Controls
            Ctrl.Width += Ctrl.Width * ratiowidth
            Ctrl.Left += Ctrl.Left * ratiowidth
            Ctrl.Top += Ctrl.Top * ratioheight
            Ctrl.Height += Ctrl.Height * ratioheight
        Next
        cuRHeight = Me.Height
        cuRWidth = Me.Width
    End Sub

    Private Sub Button2_Click(sender As Object, e As EventArgs) Handles Button2.Click
        welcome.Show()
        Me.Close()

    End Sub

    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click
        com.CommandText = "insert into login values('" & TextBox1.Text & "','" & TextBox2.Text & "','" & ComboBox1.SelectedItem & "')"
        com.Connection = con
        com.ExecuteNonQuery()

        If TextBox1.Text = "" Then
            MsgBox("Please give any Username")
        ElseIf TextBox2.Text = "" Then
            MsgBox("Please give password")
        ElseIf ComboBox1.SelectedItem = "" Then
            MsgBox("Please select any user ")
        Else
            MsgBox("Record Submitted!!!!")
            TextBox1.Clear()
            TextBox2.Clear()
            ComboBox1.ResetText()
            LOGIN.Show()
            Me.Close()
        End If
    End Sub


End Class