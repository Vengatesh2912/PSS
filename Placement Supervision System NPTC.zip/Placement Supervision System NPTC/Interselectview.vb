﻿Imports System.Data.SqlClient
Public Class Interselectview
    Dim con As SqlConnection
    Dim com As SqlCommand
    Dim rd As SqlDataReader
    Dim ada As SqlDataAdapter
    Dim ds As DataSet
    Dim dv As DataView
    Dim drv As DataRowView
    Dim cuRWidth As Integer = Me.Width
    Dim cuRHeight As Integer = Me.Height
    Private Sub Interselectview_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        'TODO: This line of code loads data into the 'PssDataSet.InterDetails' table. You can move, or remove it, as needed.
        Me.InterDetailsTableAdapter.Fill(Me.PssDataSet.InterDetails)


        con = New SqlConnection
        com = New SqlCommand
        con.ConnectionString = "Data Source=VENGATESH-PC;Initial Catalog=igi;User ID=sa;Password=aa"
        con.Open()
        com.Connection = con
        ada = New SqlDataAdapter("select *from InterDetails", con)
        ds = New DataSet
        ada.Fill(ds, "InterDetails")
        dv = New DataView(ds.Tables("InterDetails"))
        drv = dv(0)
        DataGridView1.Columns(0).DefaultCellStyle.Font = New Font("times new roman", 9, FontStyle.Regular)
        DataGridView1.Columns(1).DefaultCellStyle.Font = New Font("times new roman", 9, FontStyle.Regular)
        DataGridView1.Columns(2).DefaultCellStyle.Font = New Font("times new roman", 9, FontStyle.Regular)
        DataGridView1.Columns(3).DefaultCellStyle.Font = New Font("times new roman", 9, FontStyle.Regular)
        DataGridView1.Columns(4).DefaultCellStyle.Font = New Font("times new roman", 9, FontStyle.Regular)
        DataGridView1.Columns(5).DefaultCellStyle.Font = New Font("times new roman", 9, FontStyle.Regular)
        DataGridView1.Columns(0).HeaderText = "Company_name"
        DataGridView1.Columns(1).HeaderText = "address"
        DataGridView1.Columns(2).HeaderText = "date"
        DataGridView1.Columns(3).HeaderText = "time"
        DataGridView1.Columns(4).HeaderText = "venue"
    End Sub

    Private Sub DataGridView1_CellContentClick(sender As Object, e As DataGridViewCellEventArgs) Handles DataGridView1.CellContentClick

    End Sub

    Private Sub Button6_Click(sender As Object, e As EventArgs)
        welcome.Show()
        Me.Close()
    End Sub

    Private Sub Button5_Click(sender As Object, e As EventArgs) Handles Button5.Click
        Interview.Show()
        Me.Close()
    End Sub

    Private Sub Interselectview_Resize(sender As Object, e As EventArgs) Handles Me.Resize
        Dim ratioheight As Double = (Me.Height - cuRHeight) / cuRHeight
        Dim ratiowidth As Double = (Me.Width - cuRWidth) / cuRWidth
        For Each Ctrl As Control In Controls
            Ctrl.Width += Ctrl.Width * ratiowidth
            Ctrl.Left += Ctrl.Left * ratiowidth
            Ctrl.Top += Ctrl.Top * ratioheight
            Ctrl.Height += Ctrl.Height * ratioheight
        Next
        cuRHeight = Me.Height
        cuRWidth = Me.Width
    End Sub

    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click
        Dim xlApp As Microsoft.Office.Interop.Excel.Application
        Dim xlWorkBook As Microsoft.Office.Interop.Excel.Workbook
        Dim xlWorkSheet As Microsoft.Office.Interop.Excel.Worksheet
        Dim misValue As Object = System.Reflection.Missing.Value
        Dim i As Integer
        Dim j As Integer
        xlApp = New Microsoft.Office.Interop.Excel.Application
        xlWorkBook = xlApp.Workbooks.Add(misValue)
        xlWorkSheet = xlWorkBook.Sheets("sheet1")
        For i = 0 To DataGridView1.RowCount - 2
            For j = 0 To DataGridView1.ColumnCount - 1
                For k As Integer = 1 To DataGridView1.Columns.Count
                    xlWorkSheet.Cells(1, k) = DataGridView1.Columns(k - 1).HeaderText
                    xlWorkSheet.Cells(i + 2, j + 1) = DataGridView1(j, i).Value.ToString()
                Next
            Next
        Next
        xlWorkSheet.SaveAs("" & TextBox1.Text & ".xlsx")
        xlWorkBook.Close()
        xlApp.Quit()
        releaseObject(xlApp)
        releaseObject(xlWorkBook)
        releaseObject(xlWorkSheet)
        MsgBox("The records are inserted successfully!!!. View the File at the " & TextBox1.Text & "")
    End Sub
    Private Sub releaseObject(ByVal obj As Object)
        Try
            System.Runtime.InteropServices.Marshal.ReleaseComObject(obj)
            obj = Nothing
        Catch ex As Exception
            obj = Nothing
        Finally
            GC.Collect()
        End Try
    End Sub

    Private Sub INSERTToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles INSERTToolStripMenuItem.Click
        Insert1.Show()
        Me.Close()
    End Sub

    Private Sub UPDATEToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles UPDATEToolStripMenuItem.Click
        Update1.Show()
        Me.Close()
    End Sub

    Private Sub DELETEToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles DELETEToolStripMenuItem.Click
        Delete1.Show()
        Me.Close()
    End Sub

    Private Sub VIEWToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles VIEWToolStripMenuItem.Click
        Selectview1.Show()
        Me.Close()
    End Sub

    Private Sub LogOutToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles LogOutToolStripMenuItem.Click
        welcome.Show()
        Me.Close()
    End Sub

    Private Sub INSERTToolStripMenuItem1_Click(sender As Object, e As EventArgs) Handles INSERTToolStripMenuItem1.Click
        Interinsert1.Show()
        Me.Close()
    End Sub

    Private Sub UPDATEToolStripMenuItem1_Click(sender As Object, e As EventArgs) Handles UPDATEToolStripMenuItem1.Click
        Interupdate1.Show()
        Me.Close()
    End Sub

    Private Sub DELETEToolStripMenuItem1_Click(sender As Object, e As EventArgs) Handles DELETEToolStripMenuItem1.Click
        InterDelete1.Show()
        Me.Close()
    End Sub

    Private Sub INSERTToolStripMenuItem2_Click(sender As Object, e As EventArgs) Handles INSERTToolStripMenuItem2.Click
        pinsert1.Show()
        Me.Close()
    End Sub

    Private Sub UPDATEToolStripMenuItem2_Click(sender As Object, e As EventArgs) Handles UPDATEToolStripMenuItem2.Click
        pupdate1.Show()
        Me.Close()
    End Sub

    Private Sub DELETEToolStripMenuItem2_Click(sender As Object, e As EventArgs) Handles DELETEToolStripMenuItem2.Click
        pdelete1.Show()
        Me.Close()
    End Sub

    Private Sub VIEWToolStripMenuItem2_Click(sender As Object, e As EventArgs) Handles VIEWToolStripMenuItem2.Click
        pselectview.Show()
        Me.Close()
    End Sub

    Private Sub INSERTToolStripMenuItem3_Click(sender As Object, e As EventArgs) Handles INSERTToolStripMenuItem3.Click
        Compinsert1.Show()
        Me.Close()
    End Sub

    Private Sub UPDATEToolStripMenuItem3_Click(sender As Object, e As EventArgs) Handles UPDATEToolStripMenuItem3.Click
        Compupdate1.Show()
        Me.Close()
    End Sub

    Private Sub DELETEToolStripMenuItem3_Click(sender As Object, e As EventArgs) Handles DELETEToolStripMenuItem3.Click
        compdelete1.Show()
        Me.Close()
    End Sub

    Private Sub VIEWToolStripMenuItem3_Click(sender As Object, e As EventArgs) Handles VIEWToolStripMenuItem3.Click
        Compselectview.Show()
        Me.Close()
    End Sub

    Private Sub AddANewUserToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles AddANewUserToolStripMenuItem.Click
        registration_form.Show()
        Me.Close()
    End Sub

    Private Sub EXITToolStripMenuItem1_Click(sender As Object, e As EventArgs) Handles EXITToolStripMenuItem1.Click
        Me.Close()
    End Sub

    Private Sub MAILTHEDATASToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles MAILTHEDATASToolStripMenuItem.Click
        mailmodule1.Show()
        Me.Close()
    End Sub

    Private Sub DEPATMENTREPORTToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles DEPATMENTREPORTToolStripMenuItem.Click
        DeptReport.Show()
        Me.Close()
    End Sub

    Private Sub ChangePasswordToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles ChangePasswordToolStripMenuItem.Click
        change_password.Show()
        Me.Close()
    End Sub

    Private Sub Button2_Click(sender As Object, e As EventArgs) Handles Button2.Click
        SaveFileDialog1.ShowDialog()
        TextBox1.Text = SaveFileDialog1.FileName
    End Sub

    Private Sub SENDTHESMSToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles SENDTHESMSToolStripMenuItem.Click
        sms.Show()
        Me.Close()
    End Sub
End Class