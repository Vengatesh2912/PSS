﻿Imports System.Data.SqlClient
Public Class deptupdate2
    Dim con As SqlConnection
    Dim com As SqlCommand
    Dim rd As SqlDataReader
    Dim ada As SqlDataAdapter
    Dim ds As DataSet
    Dim dv As DataView
    Dim drv As DataRowView
    Private Sub deptupdate2_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        con = New SqlConnection
        com = New SqlCommand
        con.ConnectionString = "Data Source=VENGATESH-PC;Initial Catalog=igi;User ID=sa;Password=aa"
        con.Open()
        com.Connection = con
        ada = New SqlDataAdapter("select *from insert1 where roll_no='" & deptupdate1.ComboBox1.SelectedItem & "' ", con)
        ds = New Data.DataSet
        If ada.Fill(ds, "insert1") Then
            dv = New Data.DataView(ds.Tables("insert1"))
            drv = dv(0)
            TextBox1.Text = drv(0)
            TextBox2.Text = drv(1)
            TextBox3.Text = drv(2)
            TextBox4.Text = drv(3)
            TextBox5.Text = drv(4)
            TextBox6.Text = drv(5)
            ComboBox2.SelectedItem = drv(6)
            TextBox8.Text = drv(7)
            TextBox9.Text = drv(8)
            TextBox10.Text = drv(9)
            TextBox11.Text = drv(10)
            ComboBox1.SelectedItem = drv(11)
        End If
    End Sub

    Private Sub Button3_Click(sender As Object, e As EventArgs) Handles Button3.Click
        deptupdate1.Show()
        Me.Close()
    End Sub

    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click
        com.CommandText = "update insert1 set name='" & TextBox1.Text & "',address='" & TextBox2.Text & "',phone_no='" & TextBox3.Text & "',email='" & TextBox4.Text & "',Age='" & TextBox5.Text & "',roll_no='" & TextBox6.Text & "',department='" & ComboBox2.SelectedItem & "',year='" & TextBox8.Text & "',SSLC='" & TextBox9.Text & "',Diploma='" & TextBox10.Text & "',placed_company='" & TextBox11.Text & "',placed_or_not='" & ComboBox1.SelectedItem & "' where roll_no='" & TextBox2.Text & "' "
        com.Connection = con
        com.ExecuteNonQuery()
        MsgBox("Record Updated!!!!")
        TextBox1.Clear()
        TextBox2.Clear()
        TextBox3.Clear()
        TextBox4.Clear()
        TextBox5.Clear()
        TextBox6.Clear()
        ComboBox2.ResetText()
        TextBox8.Clear()
        TextBox9.Clear()
        TextBox10.Clear()
        TextBox11.Clear()
        ComboBox1.ResetText()

        deptupdate1.Show()
        Me.Close()
    End Sub

   


    Private Sub ChangePasswordToolStripMenuItem_Click(sender As Object, e As EventArgs)
        change_password.Show()
        Me.Close()
    End Sub

    Private Sub AddANewUserToolStripMenuItem_Click(sender As Object, e As EventArgs)
        registration_form.Show()
        Me.Close()
    End Sub

    Private Sub LogOutToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles LogOutToolStripMenuItem.Click
        LOGIN.Show()
        Me.Close()
    End Sub

    Private Sub EXITToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles EXITToolStripMenuItem.Click
        Me.Close()
    End Sub

    Private Sub INSERTToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles INSERTToolStripMenuItem.Click
        deptinsert.Show()
        Me.Close()
    End Sub

    Private Sub UPDATEToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles UPDATEToolStripMenuItem.Click
        deptupdate1.Show()
        Me.Close()
    End Sub

    Private Sub DELETEToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles DELETEToolStripMenuItem.Click
        deptdelete.Show()
        Me.Close()
    End Sub

    Private Sub VIEWToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles VIEWToolStripMenuItem.Click
        deptselectview.Show()
        Me.Close()
    End Sub

    Private Sub ComboBox2_SelectedIndexChanged(sender As Object, e As EventArgs) Handles ComboBox2.SelectedIndexChanged

    End Sub
End Class