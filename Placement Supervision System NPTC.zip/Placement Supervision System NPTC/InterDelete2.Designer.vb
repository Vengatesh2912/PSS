﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class InterDelete2
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(InterDelete2))
        Me.Button3 = New System.Windows.Forms.Button()
        Me.Label13 = New System.Windows.Forms.Label()
        Me.Button1 = New System.Windows.Forms.Button()
        Me.Label6 = New System.Windows.Forms.Label()
        Me.MenuStrip1 = New System.Windows.Forms.MenuStrip()
        Me.ExitToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.STUDENTDETAILSToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.INSERTToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.UPDATEToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.DELETEToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.VIEWToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.INTERVIEWDETAILSToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.INSERTToolStripMenuItem1 = New System.Windows.Forms.ToolStripMenuItem()
        Me.UPDATEToolStripMenuItem1 = New System.Windows.Forms.ToolStripMenuItem()
        Me.DELETEToolStripMenuItem1 = New System.Windows.Forms.ToolStripMenuItem()
        Me.VIEWToolStripMenuItem1 = New System.Windows.Forms.ToolStripMenuItem()
        Me.PLACEMENTDETAILSToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.INSERTToolStripMenuItem2 = New System.Windows.Forms.ToolStripMenuItem()
        Me.UPDATEToolStripMenuItem2 = New System.Windows.Forms.ToolStripMenuItem()
        Me.DELETEToolStripMenuItem2 = New System.Windows.Forms.ToolStripMenuItem()
        Me.VIEWToolStripMenuItem2 = New System.Windows.Forms.ToolStripMenuItem()
        Me.COMPANYDETAILSToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.INSERTToolStripMenuItem3 = New System.Windows.Forms.ToolStripMenuItem()
        Me.UPDATEToolStripMenuItem3 = New System.Windows.Forms.ToolStripMenuItem()
        Me.DELETEToolStripMenuItem3 = New System.Windows.Forms.ToolStripMenuItem()
        Me.VIEWToolStripMenuItem3 = New System.Windows.Forms.ToolStripMenuItem()
        Me.REPORTGENERATIONToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.DEPATMENTREPORTToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.MAILTHEDATASToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.SENDTHESMSToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.SettingsToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.ChangePasswordToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.LogOutToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.AddANewUserToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.EXITToolStripMenuItem1 = New System.Windows.Forms.ToolStripMenuItem()
        Me.TextBox4 = New System.Windows.Forms.TextBox()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.DateTimePicker1 = New System.Windows.Forms.DateTimePicker()
        Me.TextBox3 = New System.Windows.Forms.TextBox()
        Me.Label5 = New System.Windows.Forms.Label()
        Me.TextBox2 = New System.Windows.Forms.TextBox()
        Me.TextBox1 = New System.Windows.Forms.TextBox()
        Me.Label4 = New System.Windows.Forms.Label()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.MenuStrip1.SuspendLayout()
        Me.SuspendLayout()
        '
        'Button3
        '
        Me.Button3.Location = New System.Drawing.Point(465, 31)
        Me.Button3.Name = "Button3"
        Me.Button3.Size = New System.Drawing.Size(75, 23)
        Me.Button3.TabIndex = 92
        Me.Button3.Text = "Back"
        Me.Button3.UseVisualStyleBackColor = True
        '
        'Label13
        '
        Me.Label13.AutoSize = True
        Me.Label13.BackColor = System.Drawing.Color.Transparent
        Me.Label13.Location = New System.Drawing.Point(165, 80)
        Me.Label13.Name = "Label13"
        Me.Label13.Size = New System.Drawing.Size(225, 13)
        Me.Label13.TabIndex = 90
        Me.Label13.Text = "PLACEMENT SUPERVISION SYSTEM (PSS)"
        '
        'Button1
        '
        Me.Button1.Location = New System.Drawing.Point(228, 374)
        Me.Button1.Name = "Button1"
        Me.Button1.Size = New System.Drawing.Size(75, 23)
        Me.Button1.TabIndex = 85
        Me.Button1.Text = "Delete"
        Me.Button1.UseVisualStyleBackColor = True
        '
        'Label6
        '
        Me.Label6.AutoSize = True
        Me.Label6.BackColor = System.Drawing.Color.Transparent
        Me.Label6.Location = New System.Drawing.Point(209, 114)
        Me.Label6.Name = "Label6"
        Me.Label6.Size = New System.Drawing.Size(137, 13)
        Me.Label6.TabIndex = 95
        Me.Label6.Text = "Delete the Interview Details"
        '
        'MenuStrip1
        '
        Me.MenuStrip1.Items.AddRange(New System.Windows.Forms.ToolStripItem() {Me.ExitToolStripMenuItem, Me.SettingsToolStripMenuItem, Me.EXITToolStripMenuItem1})
        Me.MenuStrip1.Location = New System.Drawing.Point(0, 0)
        Me.MenuStrip1.Name = "MenuStrip1"
        Me.MenuStrip1.Size = New System.Drawing.Size(554, 24)
        Me.MenuStrip1.TabIndex = 101
        Me.MenuStrip1.Text = "MenuStrip1"
        '
        'ExitToolStripMenuItem
        '
        Me.ExitToolStripMenuItem.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.STUDENTDETAILSToolStripMenuItem, Me.INTERVIEWDETAILSToolStripMenuItem, Me.PLACEMENTDETAILSToolStripMenuItem, Me.COMPANYDETAILSToolStripMenuItem, Me.REPORTGENERATIONToolStripMenuItem, Me.MAILTHEDATASToolStripMenuItem, Me.SENDTHESMSToolStripMenuItem})
        Me.ExitToolStripMenuItem.Name = "ExitToolStripMenuItem"
        Me.ExitToolStripMenuItem.Size = New System.Drawing.Size(70, 20)
        Me.ExitToolStripMenuItem.Text = "Go To >>"
        '
        'STUDENTDETAILSToolStripMenuItem
        '
        Me.STUDENTDETAILSToolStripMenuItem.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.INSERTToolStripMenuItem, Me.UPDATEToolStripMenuItem, Me.DELETEToolStripMenuItem, Me.VIEWToolStripMenuItem})
        Me.STUDENTDETAILSToolStripMenuItem.Name = "STUDENTDETAILSToolStripMenuItem"
        Me.STUDENTDETAILSToolStripMenuItem.Size = New System.Drawing.Size(192, 22)
        Me.STUDENTDETAILSToolStripMenuItem.Text = "STUDENT DETAILS"
        '
        'INSERTToolStripMenuItem
        '
        Me.INSERTToolStripMenuItem.Name = "INSERTToolStripMenuItem"
        Me.INSERTToolStripMenuItem.Size = New System.Drawing.Size(118, 22)
        Me.INSERTToolStripMenuItem.Text = "INSERT"
        '
        'UPDATEToolStripMenuItem
        '
        Me.UPDATEToolStripMenuItem.Name = "UPDATEToolStripMenuItem"
        Me.UPDATEToolStripMenuItem.Size = New System.Drawing.Size(118, 22)
        Me.UPDATEToolStripMenuItem.Text = "UPDATE"
        '
        'DELETEToolStripMenuItem
        '
        Me.DELETEToolStripMenuItem.Name = "DELETEToolStripMenuItem"
        Me.DELETEToolStripMenuItem.Size = New System.Drawing.Size(118, 22)
        Me.DELETEToolStripMenuItem.Text = "DELETE"
        '
        'VIEWToolStripMenuItem
        '
        Me.VIEWToolStripMenuItem.Name = "VIEWToolStripMenuItem"
        Me.VIEWToolStripMenuItem.Size = New System.Drawing.Size(118, 22)
        Me.VIEWToolStripMenuItem.Text = "VIEW"
        '
        'INTERVIEWDETAILSToolStripMenuItem
        '
        Me.INTERVIEWDETAILSToolStripMenuItem.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.INSERTToolStripMenuItem1, Me.UPDATEToolStripMenuItem1, Me.DELETEToolStripMenuItem1, Me.VIEWToolStripMenuItem1})
        Me.INTERVIEWDETAILSToolStripMenuItem.Name = "INTERVIEWDETAILSToolStripMenuItem"
        Me.INTERVIEWDETAILSToolStripMenuItem.Size = New System.Drawing.Size(192, 22)
        Me.INTERVIEWDETAILSToolStripMenuItem.Text = "INTERVIEW DETAILS"
        '
        'INSERTToolStripMenuItem1
        '
        Me.INSERTToolStripMenuItem1.Name = "INSERTToolStripMenuItem1"
        Me.INSERTToolStripMenuItem1.Size = New System.Drawing.Size(118, 22)
        Me.INSERTToolStripMenuItem1.Text = "INSERT"
        '
        'UPDATEToolStripMenuItem1
        '
        Me.UPDATEToolStripMenuItem1.Name = "UPDATEToolStripMenuItem1"
        Me.UPDATEToolStripMenuItem1.Size = New System.Drawing.Size(118, 22)
        Me.UPDATEToolStripMenuItem1.Text = "UPDATE"
        '
        'DELETEToolStripMenuItem1
        '
        Me.DELETEToolStripMenuItem1.Name = "DELETEToolStripMenuItem1"
        Me.DELETEToolStripMenuItem1.Size = New System.Drawing.Size(118, 22)
        Me.DELETEToolStripMenuItem1.Text = "DELETE"
        '
        'VIEWToolStripMenuItem1
        '
        Me.VIEWToolStripMenuItem1.Name = "VIEWToolStripMenuItem1"
        Me.VIEWToolStripMenuItem1.Size = New System.Drawing.Size(118, 22)
        Me.VIEWToolStripMenuItem1.Text = "VIEW"
        '
        'PLACEMENTDETAILSToolStripMenuItem
        '
        Me.PLACEMENTDETAILSToolStripMenuItem.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.INSERTToolStripMenuItem2, Me.UPDATEToolStripMenuItem2, Me.DELETEToolStripMenuItem2, Me.VIEWToolStripMenuItem2})
        Me.PLACEMENTDETAILSToolStripMenuItem.Name = "PLACEMENTDETAILSToolStripMenuItem"
        Me.PLACEMENTDETAILSToolStripMenuItem.Size = New System.Drawing.Size(192, 22)
        Me.PLACEMENTDETAILSToolStripMenuItem.Text = "PLACEMENT DETAILS"
        '
        'INSERTToolStripMenuItem2
        '
        Me.INSERTToolStripMenuItem2.Name = "INSERTToolStripMenuItem2"
        Me.INSERTToolStripMenuItem2.Size = New System.Drawing.Size(118, 22)
        Me.INSERTToolStripMenuItem2.Text = "INSERT"
        '
        'UPDATEToolStripMenuItem2
        '
        Me.UPDATEToolStripMenuItem2.Name = "UPDATEToolStripMenuItem2"
        Me.UPDATEToolStripMenuItem2.Size = New System.Drawing.Size(118, 22)
        Me.UPDATEToolStripMenuItem2.Text = "UPDATE"
        '
        'DELETEToolStripMenuItem2
        '
        Me.DELETEToolStripMenuItem2.Name = "DELETEToolStripMenuItem2"
        Me.DELETEToolStripMenuItem2.Size = New System.Drawing.Size(118, 22)
        Me.DELETEToolStripMenuItem2.Text = "DELETE"
        '
        'VIEWToolStripMenuItem2
        '
        Me.VIEWToolStripMenuItem2.Name = "VIEWToolStripMenuItem2"
        Me.VIEWToolStripMenuItem2.Size = New System.Drawing.Size(118, 22)
        Me.VIEWToolStripMenuItem2.Text = "VIEW"
        '
        'COMPANYDETAILSToolStripMenuItem
        '
        Me.COMPANYDETAILSToolStripMenuItem.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.INSERTToolStripMenuItem3, Me.UPDATEToolStripMenuItem3, Me.DELETEToolStripMenuItem3, Me.VIEWToolStripMenuItem3})
        Me.COMPANYDETAILSToolStripMenuItem.Name = "COMPANYDETAILSToolStripMenuItem"
        Me.COMPANYDETAILSToolStripMenuItem.Size = New System.Drawing.Size(192, 22)
        Me.COMPANYDETAILSToolStripMenuItem.Text = "COMPANY DETAILS"
        '
        'INSERTToolStripMenuItem3
        '
        Me.INSERTToolStripMenuItem3.Name = "INSERTToolStripMenuItem3"
        Me.INSERTToolStripMenuItem3.Size = New System.Drawing.Size(118, 22)
        Me.INSERTToolStripMenuItem3.Text = "INSERT"
        '
        'UPDATEToolStripMenuItem3
        '
        Me.UPDATEToolStripMenuItem3.Name = "UPDATEToolStripMenuItem3"
        Me.UPDATEToolStripMenuItem3.Size = New System.Drawing.Size(118, 22)
        Me.UPDATEToolStripMenuItem3.Text = "UPDATE"
        '
        'DELETEToolStripMenuItem3
        '
        Me.DELETEToolStripMenuItem3.Name = "DELETEToolStripMenuItem3"
        Me.DELETEToolStripMenuItem3.Size = New System.Drawing.Size(118, 22)
        Me.DELETEToolStripMenuItem3.Text = "DELETE"
        '
        'VIEWToolStripMenuItem3
        '
        Me.VIEWToolStripMenuItem3.Name = "VIEWToolStripMenuItem3"
        Me.VIEWToolStripMenuItem3.Size = New System.Drawing.Size(118, 22)
        Me.VIEWToolStripMenuItem3.Text = "VIEW"
        '
        'REPORTGENERATIONToolStripMenuItem
        '
        Me.REPORTGENERATIONToolStripMenuItem.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.DEPATMENTREPORTToolStripMenuItem})
        Me.REPORTGENERATIONToolStripMenuItem.Name = "REPORTGENERATIONToolStripMenuItem"
        Me.REPORTGENERATIONToolStripMenuItem.Size = New System.Drawing.Size(192, 22)
        Me.REPORTGENERATIONToolStripMenuItem.Text = "REPORT GENERATION"
        '
        'DEPATMENTREPORTToolStripMenuItem
        '
        Me.DEPATMENTREPORTToolStripMenuItem.Name = "DEPATMENTREPORTToolStripMenuItem"
        Me.DEPATMENTREPORTToolStripMenuItem.Size = New System.Drawing.Size(196, 22)
        Me.DEPATMENTREPORTToolStripMenuItem.Text = "DEPARTMENT REPORT"
        '
        'MAILTHEDATASToolStripMenuItem
        '
        Me.MAILTHEDATASToolStripMenuItem.Name = "MAILTHEDATASToolStripMenuItem"
        Me.MAILTHEDATASToolStripMenuItem.Size = New System.Drawing.Size(192, 22)
        Me.MAILTHEDATASToolStripMenuItem.Text = "SEND THE MAIL"
        '
        'SENDTHESMSToolStripMenuItem
        '
        Me.SENDTHESMSToolStripMenuItem.Name = "SENDTHESMSToolStripMenuItem"
        Me.SENDTHESMSToolStripMenuItem.Size = New System.Drawing.Size(192, 22)
        Me.SENDTHESMSToolStripMenuItem.Text = "SEND THE SMS"
        '
        'SettingsToolStripMenuItem
        '
        Me.SettingsToolStripMenuItem.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.ChangePasswordToolStripMenuItem, Me.LogOutToolStripMenuItem, Me.AddANewUserToolStripMenuItem})
        Me.SettingsToolStripMenuItem.Name = "SettingsToolStripMenuItem"
        Me.SettingsToolStripMenuItem.Size = New System.Drawing.Size(71, 20)
        Me.SettingsToolStripMenuItem.Text = "SETTINGS"
        '
        'ChangePasswordToolStripMenuItem
        '
        Me.ChangePasswordToolStripMenuItem.Name = "ChangePasswordToolStripMenuItem"
        Me.ChangePasswordToolStripMenuItem.Size = New System.Drawing.Size(168, 22)
        Me.ChangePasswordToolStripMenuItem.Text = "Change Password"
        '
        'LogOutToolStripMenuItem
        '
        Me.LogOutToolStripMenuItem.Name = "LogOutToolStripMenuItem"
        Me.LogOutToolStripMenuItem.Size = New System.Drawing.Size(168, 22)
        Me.LogOutToolStripMenuItem.Text = "Log Out"
        '
        'AddANewUserToolStripMenuItem
        '
        Me.AddANewUserToolStripMenuItem.Name = "AddANewUserToolStripMenuItem"
        Me.AddANewUserToolStripMenuItem.Size = New System.Drawing.Size(168, 22)
        Me.AddANewUserToolStripMenuItem.Text = "Add a New User"
        '
        'EXITToolStripMenuItem1
        '
        Me.EXITToolStripMenuItem1.Name = "EXITToolStripMenuItem1"
        Me.EXITToolStripMenuItem1.Size = New System.Drawing.Size(42, 20)
        Me.EXITToolStripMenuItem1.Text = "EXIT"
        '
        'TextBox4
        '
        Me.TextBox4.Location = New System.Drawing.Point(280, 283)
        Me.TextBox4.Name = "TextBox4"
        Me.TextBox4.Size = New System.Drawing.Size(153, 20)
        Me.TextBox4.TabIndex = 115
        '
        'Label3
        '
        Me.Label3.AutoSize = True
        Me.Label3.BackColor = System.Drawing.Color.Transparent
        Me.Label3.Location = New System.Drawing.Point(90, 290)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(33, 13)
        Me.Label3.TabIndex = 114
        Me.Label3.Text = "Time:"
        '
        'DateTimePicker1
        '
        Me.DateTimePicker1.Location = New System.Drawing.Point(280, 238)
        Me.DateTimePicker1.Name = "DateTimePicker1"
        Me.DateTimePicker1.Size = New System.Drawing.Size(200, 20)
        Me.DateTimePicker1.TabIndex = 113
        '
        'TextBox3
        '
        Me.TextBox3.Location = New System.Drawing.Point(280, 328)
        Me.TextBox3.Name = "TextBox3"
        Me.TextBox3.Size = New System.Drawing.Size(153, 20)
        Me.TextBox3.TabIndex = 112
        '
        'Label5
        '
        Me.Label5.AutoSize = True
        Me.Label5.BackColor = System.Drawing.Color.Transparent
        Me.Label5.Location = New System.Drawing.Point(90, 331)
        Me.Label5.Name = "Label5"
        Me.Label5.Size = New System.Drawing.Size(41, 13)
        Me.Label5.TabIndex = 111
        Me.Label5.Text = "Venue:"
        '
        'TextBox2
        '
        Me.TextBox2.Location = New System.Drawing.Point(280, 192)
        Me.TextBox2.Name = "TextBox2"
        Me.TextBox2.Size = New System.Drawing.Size(153, 20)
        Me.TextBox2.TabIndex = 110
        '
        'TextBox1
        '
        Me.TextBox1.Location = New System.Drawing.Point(280, 146)
        Me.TextBox1.Name = "TextBox1"
        Me.TextBox1.Size = New System.Drawing.Size(153, 20)
        Me.TextBox1.TabIndex = 109
        '
        'Label4
        '
        Me.Label4.AutoSize = True
        Me.Label4.BackColor = System.Drawing.Color.Transparent
        Me.Label4.Location = New System.Drawing.Point(90, 244)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(33, 13)
        Me.Label4.TabIndex = 108
        Me.Label4.Text = "Date:"
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.BackColor = System.Drawing.Color.Transparent
        Me.Label2.Location = New System.Drawing.Point(90, 195)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(48, 13)
        Me.Label2.TabIndex = 107
        Me.Label2.Text = "Address:"
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.BackColor = System.Drawing.Color.Transparent
        Me.Label1.Location = New System.Drawing.Point(90, 149)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(83, 13)
        Me.Label1.TabIndex = 106
        Me.Label1.Text = "Company name:"
        '
        'InterDelete2
        '
        Me.AcceptButton = Me.Button1
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackgroundImage = CType(resources.GetObject("$this.BackgroundImage"), System.Drawing.Image)
        Me.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.ClientSize = New System.Drawing.Size(554, 419)
        Me.Controls.Add(Me.TextBox4)
        Me.Controls.Add(Me.Label3)
        Me.Controls.Add(Me.DateTimePicker1)
        Me.Controls.Add(Me.TextBox3)
        Me.Controls.Add(Me.Label5)
        Me.Controls.Add(Me.TextBox2)
        Me.Controls.Add(Me.TextBox1)
        Me.Controls.Add(Me.Label4)
        Me.Controls.Add(Me.Label2)
        Me.Controls.Add(Me.Label1)
        Me.Controls.Add(Me.MenuStrip1)
        Me.Controls.Add(Me.Label6)
        Me.Controls.Add(Me.Button3)
        Me.Controls.Add(Me.Label13)
        Me.Controls.Add(Me.Button1)
        Me.Name = "InterDelete2"
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
        Me.Text = "INTERVIEW DETAILS"
        Me.MenuStrip1.ResumeLayout(False)
        Me.MenuStrip1.PerformLayout()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents Button3 As System.Windows.Forms.Button
    Friend WithEvents Label13 As System.Windows.Forms.Label
    Friend WithEvents Button1 As System.Windows.Forms.Button
    Friend WithEvents Label6 As System.Windows.Forms.Label
    Friend WithEvents MenuStrip1 As System.Windows.Forms.MenuStrip
    Friend WithEvents ExitToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents STUDENTDETAILSToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents INSERTToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents UPDATEToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents DELETEToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents VIEWToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents INTERVIEWDETAILSToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents INSERTToolStripMenuItem1 As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents UPDATEToolStripMenuItem1 As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents DELETEToolStripMenuItem1 As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents VIEWToolStripMenuItem1 As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents PLACEMENTDETAILSToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents INSERTToolStripMenuItem2 As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents UPDATEToolStripMenuItem2 As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents DELETEToolStripMenuItem2 As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents VIEWToolStripMenuItem2 As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents COMPANYDETAILSToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents INSERTToolStripMenuItem3 As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents UPDATEToolStripMenuItem3 As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents DELETEToolStripMenuItem3 As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents VIEWToolStripMenuItem3 As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents REPORTGENERATIONToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents DEPATMENTREPORTToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents MAILTHEDATASToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents SettingsToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents ChangePasswordToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents LogOutToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents AddANewUserToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents EXITToolStripMenuItem1 As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents SENDTHESMSToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents TextBox4 As System.Windows.Forms.TextBox
    Friend WithEvents Label3 As System.Windows.Forms.Label
    Friend WithEvents DateTimePicker1 As System.Windows.Forms.DateTimePicker
    Friend WithEvents TextBox3 As System.Windows.Forms.TextBox
    Friend WithEvents Label5 As System.Windows.Forms.Label
    Friend WithEvents TextBox2 As System.Windows.Forms.TextBox
    Friend WithEvents TextBox1 As System.Windows.Forms.TextBox
    Friend WithEvents Label4 As System.Windows.Forms.Label
    Friend WithEvents Label2 As System.Windows.Forms.Label
    Friend WithEvents Label1 As System.Windows.Forms.Label
End Class
