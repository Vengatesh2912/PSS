﻿Imports System.Data.SqlClient
Imports System.IO
Imports System.Text
Imports System.Data.OleDb
Public Class LOGIN
    Dim cuRWidth As Integer = Me.Width
    Dim cuRHeight As Integer = Me.Height
    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click
        Dim con As SqlConnection = New SqlConnection("Data Source=VENGATESH-PC;Initial Catalog=igi;User ID=sa;Password=aa")
        Dim cmd As SqlCommand = New SqlCommand("select * from login where username='" & TextBox1.Text & "' and password='" & TextBox2.Text & "' and usertype='" & ComboBox1.SelectedItem & "'", con)
        Dim sda As SqlDataAdapter = New SqlDataAdapter(cmd)
        Dim dt As DataTable = New DataTable()
        sda.Fill(dt)
        If (dt.Rows.Count > 0) Then
            If (ComboBox1.SelectedIndex = 0) Then

                details.Show()
                Me.Close()

            End If

        ElseIf ComboBox1.SelectedItem = "Placement Co-ordinator" Then

            If ComboBox2.SelectedItem = "CT" And TextBox1.Text = "ct1" And TextBox2.Text = "ct1" Then
                deptmenu.Show()
                Me.Close()
            ElseIf ComboBox2.SelectedItem = "ECE" And TextBox1.Text = "ece1" And TextBox2.Text = "ece1" Then
                deptmenu.Show()
                Me.Close()
            ElseIf ComboBox2.SelectedItem = "EEE" And TextBox1.Text = "eee1" And TextBox2.Text = "eee1" Then
                deptmenu.Show()
                Me.Close()
            ElseIf ComboBox2.SelectedItem = "ICE" And TextBox1.Text = "ice1" And TextBox2.Text = "ice1" Then
                deptmenu.Show()
                Me.Close()
            ElseIf ComboBox2.SelectedItem = "AUTO" And TextBox1.Text = "auto1" And TextBox2.Text = "auto1" Then
                deptmenu.Show()
                Me.Close()
            ElseIf ComboBox2.SelectedItem = "AUTO(SF)" And TextBox1.Text = "autosf1" And TextBox2.Text = "autosf1" Then
                deptmenu.Show()
                Me.Close()
            ElseIf ComboBox2.SelectedItem = "MECH(R&AC)" And TextBox1.Text = "mechrac1" And TextBox2.Text = "mechrac1" Then
                deptmenu.Show()
                Me.Close()
            ElseIf ComboBox2.SelectedItem = "CIVIL" And TextBox1.Text = "civil1" And TextBox2.Text = "civil1" Then
                deptmenu.Show()
                Me.Close()
            ElseIf ComboBox2.SelectedItem = "MECH(SF)" And TextBox1.Text = "mechsf1" And TextBox2.Text = "mechsf1" Then
                deptmenu.Show()
                Me.Close()
            ElseIf ComboBox2.SelectedItem = "MECH(TVS)" And TextBox1.Text = "mechtvs1" And TextBox2.Text = "mechtvs1" Then
                deptmenu.Show()
                Me.Close()
            ElseIf ComboBox2.SelectedItem = "EEE(SF)" And TextBox1.Text = "eeesf1" And TextBox2.Text = "eeesf1" Then
                deptmenu.Show()
                Me.Close()
            ElseIf ComboBox2.SelectedItem = "ECE(SF)" And TextBox1.Text = "ecesf1" And TextBox2.Text = "ecesf1" Then
                deptmenu.Show()
                Me.Close()
            ElseIf ComboBox2.SelectedItem = "AUTO(SF)" And TextBox1.Text = "autosf1" And TextBox2.Text = "autosf1" Then
                deptmenu.Show()
                Me.Close()
            ElseIf ComboBox2.SelectedItem = "MECH(SW)" And TextBox1.Text = "mechsw1" And TextBox2.Text = "mechsw1" Then
                deptmenu.Show()
                Me.Close()
            ElseIf ComboBox2.SelectedItem = "CIVIL(SF)" And TextBox1.Text = "civilsf1" And TextBox2.Text = "civilsf1" Then
                deptmenu.Show()
                Me.Close()
            ElseIf ComboBox2.SelectedItem = "PT" And TextBox1.Text = "pt1" And TextBox2.Text = "pt1" Then
                deptmenu.Show()
                Me.Close()
            ElseIf ComboBox2.SelectedItem = "TT" And TextBox1.Text = "tt1" And TextBox2.Text = "tt1" Then
                deptmenu.Show()
                Me.Close()


            ElseIf ComboBox2.SelectedItem = "" And TextBox1.Text = "" And TextBox2.Text = "" Then
                MsgBox("Enter all details.....")

            Else
                MsgBox("INVALID LOGIN......")
                TextBox1.Clear()
                TextBox2.Clear()
            End If
            ElseIf ComboBox1.SelectedItem = "" And TextBox1.Text = "" And TextBox2.Text = "" Then
        MsgBox("Enter all details.....")

            Else
        MsgBox("INVALID LOGIN......")
        TextBox1.Clear()
        TextBox2.Clear()
            End If

    End Sub

    Private Sub Button3_Click(sender As Object, e As EventArgs) Handles Button3.Click
        welcome.Show()
        Me.Close()
    End Sub

    Private Sub Button2_Click(sender As Object, e As EventArgs) Handles Button2.Click
        welcome.Show()
        Me.Close()
    End Sub

    Private Sub ComboBox1_SelectedIndexChanged(sender As Object, e As EventArgs) Handles ComboBox1.SelectedIndexChanged
        If ComboBox1.SelectedItem = "Placement Co-ordinator" Then
            Label5.Enabled = True
            ComboBox2.Enabled = True
        ElseIf ComboBox1.SelectedItem = "Placement Officer" Then
            Label5.Enabled = False
            ComboBox2.Enabled = False
        End If
    End Sub

    Private Sub LOGIN_Resize(sender As Object, e As EventArgs) Handles Me.Resize
        Dim ratioheight As Double = (Me.Height - cuRHeight) / cuRHeight
        Dim ratiowidth As Double = (Me.Width - cuRWidth) / cuRWidth
        For Each Ctrl As Control In Controls
            Ctrl.Width += Ctrl.Width * ratiowidth
            Ctrl.Left += Ctrl.Left * ratiowidth
            Ctrl.Top += Ctrl.Top * ratioheight
            Ctrl.Height += Ctrl.Height * ratioheight
        Next
        cuRHeight = Me.Height
        cuRWidth = Me.Width

    End Sub

    Private Sub LOGIN_Load(sender As Object, e As EventArgs) Handles MyBase.Load

    End Sub
End Class