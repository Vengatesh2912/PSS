﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Interselectview
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(Interselectview))
        Me.Button5 = New System.Windows.Forms.Button()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.DataGridView1 = New System.Windows.Forms.DataGridView()
        Me.Button1 = New System.Windows.Forms.Button()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.MenuStrip1 = New System.Windows.Forms.MenuStrip()
        Me.ExitToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.STUDENTDETAILSToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.INSERTToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.UPDATEToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.DELETEToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.VIEWToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.INTERVIEWDETAILSToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.INSERTToolStripMenuItem1 = New System.Windows.Forms.ToolStripMenuItem()
        Me.UPDATEToolStripMenuItem1 = New System.Windows.Forms.ToolStripMenuItem()
        Me.DELETEToolStripMenuItem1 = New System.Windows.Forms.ToolStripMenuItem()
        Me.VIEWToolStripMenuItem1 = New System.Windows.Forms.ToolStripMenuItem()
        Me.PLACEMENTDETAILSToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.INSERTToolStripMenuItem2 = New System.Windows.Forms.ToolStripMenuItem()
        Me.UPDATEToolStripMenuItem2 = New System.Windows.Forms.ToolStripMenuItem()
        Me.DELETEToolStripMenuItem2 = New System.Windows.Forms.ToolStripMenuItem()
        Me.VIEWToolStripMenuItem2 = New System.Windows.Forms.ToolStripMenuItem()
        Me.COMPANYDETAILSToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.INSERTToolStripMenuItem3 = New System.Windows.Forms.ToolStripMenuItem()
        Me.UPDATEToolStripMenuItem3 = New System.Windows.Forms.ToolStripMenuItem()
        Me.DELETEToolStripMenuItem3 = New System.Windows.Forms.ToolStripMenuItem()
        Me.VIEWToolStripMenuItem3 = New System.Windows.Forms.ToolStripMenuItem()
        Me.REPORTGENERATIONToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.DEPATMENTREPORTToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.MAILTHEDATASToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.SENDTHESMSToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.SettingsToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.ChangePasswordToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.LogOutToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.AddANewUserToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.EXITToolStripMenuItem1 = New System.Windows.Forms.ToolStripMenuItem()
        Me.Button2 = New System.Windows.Forms.Button()
        Me.Label5 = New System.Windows.Forms.Label()
        Me.TextBox1 = New System.Windows.Forms.TextBox()
        Me.SaveFileDialog1 = New System.Windows.Forms.SaveFileDialog()
        Me.PssDataSet = New PSS.PssDataSet()
        Me.InterDetailsBindingSource = New System.Windows.Forms.BindingSource(Me.components)
        Me.InterDetailsTableAdapter = New PSS.PssDataSetTableAdapters.InterDetailsTableAdapter()
        Me.CompanynameDataGridViewTextBoxColumn = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.AddressDataGridViewTextBoxColumn = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.DataGridViewTextBoxColumn1 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.DataGridViewTextBoxColumn2 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.VenueDataGridViewTextBoxColumn = New System.Windows.Forms.DataGridViewTextBoxColumn()
        CType(Me.DataGridView1, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.MenuStrip1.SuspendLayout()
        CType(Me.PssDataSet, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.InterDetailsBindingSource, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'Button5
        '
        Me.Button5.Location = New System.Drawing.Point(547, 33)
        Me.Button5.Name = "Button5"
        Me.Button5.Size = New System.Drawing.Size(75, 23)
        Me.Button5.TabIndex = 88
        Me.Button5.Text = "Back"
        Me.Button5.UseVisualStyleBackColor = True
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.BackColor = System.Drawing.Color.Transparent
        Me.Label1.Location = New System.Drawing.Point(211, 61)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(225, 13)
        Me.Label1.TabIndex = 86
        Me.Label1.Text = "PLACEMENT SUPERVISION SYSTEM (PSS)"
        '
        'DataGridView1
        '
        Me.DataGridView1.AutoGenerateColumns = False
        Me.DataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.DataGridView1.Columns.AddRange(New System.Windows.Forms.DataGridViewColumn() {Me.CompanynameDataGridViewTextBoxColumn, Me.AddressDataGridViewTextBoxColumn, Me.DataGridViewTextBoxColumn1, Me.DataGridViewTextBoxColumn2, Me.VenueDataGridViewTextBoxColumn})
        Me.DataGridView1.DataSource = Me.InterDetailsBindingSource
        Me.DataGridView1.Location = New System.Drawing.Point(51, 145)
        Me.DataGridView1.Name = "DataGridView1"
        Me.DataGridView1.Size = New System.Drawing.Size(544, 309)
        Me.DataGridView1.TabIndex = 89
        '
        'Button1
        '
        Me.Button1.Location = New System.Drawing.Point(399, 485)
        Me.Button1.Name = "Button1"
        Me.Button1.Size = New System.Drawing.Size(108, 36)
        Me.Button1.TabIndex = 90
        Me.Button1.Text = "Export to Excel"
        Me.Button1.UseVisualStyleBackColor = True
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.BackColor = System.Drawing.Color.Transparent
        Me.Label2.Location = New System.Drawing.Point(262, 95)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(129, 13)
        Me.Label2.TabIndex = 91
        Me.Label2.Text = "View the Interview Details"
        '
        'MenuStrip1
        '
        Me.MenuStrip1.Items.AddRange(New System.Windows.Forms.ToolStripItem() {Me.ExitToolStripMenuItem, Me.SettingsToolStripMenuItem, Me.EXITToolStripMenuItem1})
        Me.MenuStrip1.Location = New System.Drawing.Point(0, 0)
        Me.MenuStrip1.Name = "MenuStrip1"
        Me.MenuStrip1.Size = New System.Drawing.Size(644, 24)
        Me.MenuStrip1.TabIndex = 101
        Me.MenuStrip1.Text = "MenuStrip1"
        '
        'ExitToolStripMenuItem
        '
        Me.ExitToolStripMenuItem.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.STUDENTDETAILSToolStripMenuItem, Me.INTERVIEWDETAILSToolStripMenuItem, Me.PLACEMENTDETAILSToolStripMenuItem, Me.COMPANYDETAILSToolStripMenuItem, Me.REPORTGENERATIONToolStripMenuItem, Me.MAILTHEDATASToolStripMenuItem, Me.SENDTHESMSToolStripMenuItem})
        Me.ExitToolStripMenuItem.Name = "ExitToolStripMenuItem"
        Me.ExitToolStripMenuItem.Size = New System.Drawing.Size(70, 20)
        Me.ExitToolStripMenuItem.Text = "Go To >>"
        '
        'STUDENTDETAILSToolStripMenuItem
        '
        Me.STUDENTDETAILSToolStripMenuItem.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.INSERTToolStripMenuItem, Me.UPDATEToolStripMenuItem, Me.DELETEToolStripMenuItem, Me.VIEWToolStripMenuItem})
        Me.STUDENTDETAILSToolStripMenuItem.Name = "STUDENTDETAILSToolStripMenuItem"
        Me.STUDENTDETAILSToolStripMenuItem.Size = New System.Drawing.Size(192, 22)
        Me.STUDENTDETAILSToolStripMenuItem.Text = "STUDENT DETAILS"
        '
        'INSERTToolStripMenuItem
        '
        Me.INSERTToolStripMenuItem.Name = "INSERTToolStripMenuItem"
        Me.INSERTToolStripMenuItem.Size = New System.Drawing.Size(118, 22)
        Me.INSERTToolStripMenuItem.Text = "INSERT"
        '
        'UPDATEToolStripMenuItem
        '
        Me.UPDATEToolStripMenuItem.Name = "UPDATEToolStripMenuItem"
        Me.UPDATEToolStripMenuItem.Size = New System.Drawing.Size(118, 22)
        Me.UPDATEToolStripMenuItem.Text = "UPDATE"
        '
        'DELETEToolStripMenuItem
        '
        Me.DELETEToolStripMenuItem.Name = "DELETEToolStripMenuItem"
        Me.DELETEToolStripMenuItem.Size = New System.Drawing.Size(118, 22)
        Me.DELETEToolStripMenuItem.Text = "DELETE"
        '
        'VIEWToolStripMenuItem
        '
        Me.VIEWToolStripMenuItem.Name = "VIEWToolStripMenuItem"
        Me.VIEWToolStripMenuItem.Size = New System.Drawing.Size(118, 22)
        Me.VIEWToolStripMenuItem.Text = "VIEW"
        '
        'INTERVIEWDETAILSToolStripMenuItem
        '
        Me.INTERVIEWDETAILSToolStripMenuItem.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.INSERTToolStripMenuItem1, Me.UPDATEToolStripMenuItem1, Me.DELETEToolStripMenuItem1, Me.VIEWToolStripMenuItem1})
        Me.INTERVIEWDETAILSToolStripMenuItem.Name = "INTERVIEWDETAILSToolStripMenuItem"
        Me.INTERVIEWDETAILSToolStripMenuItem.Size = New System.Drawing.Size(192, 22)
        Me.INTERVIEWDETAILSToolStripMenuItem.Text = "INTERVIEW DETAILS"
        '
        'INSERTToolStripMenuItem1
        '
        Me.INSERTToolStripMenuItem1.Name = "INSERTToolStripMenuItem1"
        Me.INSERTToolStripMenuItem1.Size = New System.Drawing.Size(118, 22)
        Me.INSERTToolStripMenuItem1.Text = "INSERT"
        '
        'UPDATEToolStripMenuItem1
        '
        Me.UPDATEToolStripMenuItem1.Name = "UPDATEToolStripMenuItem1"
        Me.UPDATEToolStripMenuItem1.Size = New System.Drawing.Size(118, 22)
        Me.UPDATEToolStripMenuItem1.Text = "UPDATE"
        '
        'DELETEToolStripMenuItem1
        '
        Me.DELETEToolStripMenuItem1.Name = "DELETEToolStripMenuItem1"
        Me.DELETEToolStripMenuItem1.Size = New System.Drawing.Size(118, 22)
        Me.DELETEToolStripMenuItem1.Text = "DELETE"
        '
        'VIEWToolStripMenuItem1
        '
        Me.VIEWToolStripMenuItem1.Name = "VIEWToolStripMenuItem1"
        Me.VIEWToolStripMenuItem1.Size = New System.Drawing.Size(118, 22)
        Me.VIEWToolStripMenuItem1.Text = "VIEW"
        '
        'PLACEMENTDETAILSToolStripMenuItem
        '
        Me.PLACEMENTDETAILSToolStripMenuItem.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.INSERTToolStripMenuItem2, Me.UPDATEToolStripMenuItem2, Me.DELETEToolStripMenuItem2, Me.VIEWToolStripMenuItem2})
        Me.PLACEMENTDETAILSToolStripMenuItem.Name = "PLACEMENTDETAILSToolStripMenuItem"
        Me.PLACEMENTDETAILSToolStripMenuItem.Size = New System.Drawing.Size(192, 22)
        Me.PLACEMENTDETAILSToolStripMenuItem.Text = "PLACEMENT DETAILS"
        '
        'INSERTToolStripMenuItem2
        '
        Me.INSERTToolStripMenuItem2.Name = "INSERTToolStripMenuItem2"
        Me.INSERTToolStripMenuItem2.Size = New System.Drawing.Size(118, 22)
        Me.INSERTToolStripMenuItem2.Text = "INSERT"
        '
        'UPDATEToolStripMenuItem2
        '
        Me.UPDATEToolStripMenuItem2.Name = "UPDATEToolStripMenuItem2"
        Me.UPDATEToolStripMenuItem2.Size = New System.Drawing.Size(118, 22)
        Me.UPDATEToolStripMenuItem2.Text = "UPDATE"
        '
        'DELETEToolStripMenuItem2
        '
        Me.DELETEToolStripMenuItem2.Name = "DELETEToolStripMenuItem2"
        Me.DELETEToolStripMenuItem2.Size = New System.Drawing.Size(118, 22)
        Me.DELETEToolStripMenuItem2.Text = "DELETE"
        '
        'VIEWToolStripMenuItem2
        '
        Me.VIEWToolStripMenuItem2.Name = "VIEWToolStripMenuItem2"
        Me.VIEWToolStripMenuItem2.Size = New System.Drawing.Size(118, 22)
        Me.VIEWToolStripMenuItem2.Text = "VIEW"
        '
        'COMPANYDETAILSToolStripMenuItem
        '
        Me.COMPANYDETAILSToolStripMenuItem.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.INSERTToolStripMenuItem3, Me.UPDATEToolStripMenuItem3, Me.DELETEToolStripMenuItem3, Me.VIEWToolStripMenuItem3})
        Me.COMPANYDETAILSToolStripMenuItem.Name = "COMPANYDETAILSToolStripMenuItem"
        Me.COMPANYDETAILSToolStripMenuItem.Size = New System.Drawing.Size(192, 22)
        Me.COMPANYDETAILSToolStripMenuItem.Text = "COMPANY DETAILS"
        '
        'INSERTToolStripMenuItem3
        '
        Me.INSERTToolStripMenuItem3.Name = "INSERTToolStripMenuItem3"
        Me.INSERTToolStripMenuItem3.Size = New System.Drawing.Size(118, 22)
        Me.INSERTToolStripMenuItem3.Text = "INSERT"
        '
        'UPDATEToolStripMenuItem3
        '
        Me.UPDATEToolStripMenuItem3.Name = "UPDATEToolStripMenuItem3"
        Me.UPDATEToolStripMenuItem3.Size = New System.Drawing.Size(118, 22)
        Me.UPDATEToolStripMenuItem3.Text = "UPDATE"
        '
        'DELETEToolStripMenuItem3
        '
        Me.DELETEToolStripMenuItem3.Name = "DELETEToolStripMenuItem3"
        Me.DELETEToolStripMenuItem3.Size = New System.Drawing.Size(118, 22)
        Me.DELETEToolStripMenuItem3.Text = "DELETE"
        '
        'VIEWToolStripMenuItem3
        '
        Me.VIEWToolStripMenuItem3.Name = "VIEWToolStripMenuItem3"
        Me.VIEWToolStripMenuItem3.Size = New System.Drawing.Size(118, 22)
        Me.VIEWToolStripMenuItem3.Text = "VIEW"
        '
        'REPORTGENERATIONToolStripMenuItem
        '
        Me.REPORTGENERATIONToolStripMenuItem.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.DEPATMENTREPORTToolStripMenuItem})
        Me.REPORTGENERATIONToolStripMenuItem.Name = "REPORTGENERATIONToolStripMenuItem"
        Me.REPORTGENERATIONToolStripMenuItem.Size = New System.Drawing.Size(192, 22)
        Me.REPORTGENERATIONToolStripMenuItem.Text = "REPORT GENERATION"
        '
        'DEPATMENTREPORTToolStripMenuItem
        '
        Me.DEPATMENTREPORTToolStripMenuItem.Name = "DEPATMENTREPORTToolStripMenuItem"
        Me.DEPATMENTREPORTToolStripMenuItem.Size = New System.Drawing.Size(196, 22)
        Me.DEPATMENTREPORTToolStripMenuItem.Text = "DEPARTMENT REPORT"
        '
        'MAILTHEDATASToolStripMenuItem
        '
        Me.MAILTHEDATASToolStripMenuItem.Name = "MAILTHEDATASToolStripMenuItem"
        Me.MAILTHEDATASToolStripMenuItem.Size = New System.Drawing.Size(192, 22)
        Me.MAILTHEDATASToolStripMenuItem.Text = "SEND THE MAIL"
        '
        'SENDTHESMSToolStripMenuItem
        '
        Me.SENDTHESMSToolStripMenuItem.Name = "SENDTHESMSToolStripMenuItem"
        Me.SENDTHESMSToolStripMenuItem.Size = New System.Drawing.Size(192, 22)
        Me.SENDTHESMSToolStripMenuItem.Text = "SEND THE SMS"
        '
        'SettingsToolStripMenuItem
        '
        Me.SettingsToolStripMenuItem.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.ChangePasswordToolStripMenuItem, Me.LogOutToolStripMenuItem, Me.AddANewUserToolStripMenuItem})
        Me.SettingsToolStripMenuItem.Name = "SettingsToolStripMenuItem"
        Me.SettingsToolStripMenuItem.Size = New System.Drawing.Size(71, 20)
        Me.SettingsToolStripMenuItem.Text = "SETTINGS"
        '
        'ChangePasswordToolStripMenuItem
        '
        Me.ChangePasswordToolStripMenuItem.Name = "ChangePasswordToolStripMenuItem"
        Me.ChangePasswordToolStripMenuItem.Size = New System.Drawing.Size(168, 22)
        Me.ChangePasswordToolStripMenuItem.Text = "Change Password"
        '
        'LogOutToolStripMenuItem
        '
        Me.LogOutToolStripMenuItem.Name = "LogOutToolStripMenuItem"
        Me.LogOutToolStripMenuItem.Size = New System.Drawing.Size(168, 22)
        Me.LogOutToolStripMenuItem.Text = "Log Out"
        '
        'AddANewUserToolStripMenuItem
        '
        Me.AddANewUserToolStripMenuItem.Name = "AddANewUserToolStripMenuItem"
        Me.AddANewUserToolStripMenuItem.Size = New System.Drawing.Size(168, 22)
        Me.AddANewUserToolStripMenuItem.Text = "Add a New User"
        '
        'EXITToolStripMenuItem1
        '
        Me.EXITToolStripMenuItem1.Name = "EXITToolStripMenuItem1"
        Me.EXITToolStripMenuItem1.Size = New System.Drawing.Size(42, 20)
        Me.EXITToolStripMenuItem1.Text = "EXIT"
        '
        'Button2
        '
        Me.Button2.Location = New System.Drawing.Point(320, 493)
        Me.Button2.Name = "Button2"
        Me.Button2.Size = New System.Drawing.Size(24, 21)
        Me.Button2.TabIndex = 200
        Me.Button2.Text = "..."
        Me.Button2.UseVisualStyleBackColor = True
        '
        'Label5
        '
        Me.Label5.AutoSize = True
        Me.Label5.BackColor = System.Drawing.Color.Transparent
        Me.Label5.Location = New System.Drawing.Point(147, 496)
        Me.Label5.Name = "Label5"
        Me.Label5.Size = New System.Drawing.Size(50, 13)
        Me.Label5.TabIndex = 199
        Me.Label5.Text = "Save As:"
        '
        'TextBox1
        '
        Me.TextBox1.Location = New System.Drawing.Point(214, 493)
        Me.TextBox1.Name = "TextBox1"
        Me.TextBox1.Size = New System.Drawing.Size(100, 20)
        Me.TextBox1.TabIndex = 198
        '
        'PssDataSet
        '
        Me.PssDataSet.DataSetName = "PssDataSet"
        Me.PssDataSet.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema
        '
        'InterDetailsBindingSource
        '
        Me.InterDetailsBindingSource.DataMember = "InterDetails"
        Me.InterDetailsBindingSource.DataSource = Me.PssDataSet
        '
        'InterDetailsTableAdapter
        '
        Me.InterDetailsTableAdapter.ClearBeforeFill = True
        '
        'CompanynameDataGridViewTextBoxColumn
        '
        Me.CompanynameDataGridViewTextBoxColumn.DataPropertyName = "Company_name"
        Me.CompanynameDataGridViewTextBoxColumn.HeaderText = "Company_name"
        Me.CompanynameDataGridViewTextBoxColumn.Name = "CompanynameDataGridViewTextBoxColumn"
        '
        'AddressDataGridViewTextBoxColumn
        '
        Me.AddressDataGridViewTextBoxColumn.DataPropertyName = "address"
        Me.AddressDataGridViewTextBoxColumn.HeaderText = "address"
        Me.AddressDataGridViewTextBoxColumn.Name = "AddressDataGridViewTextBoxColumn"
        '
        'DataGridViewTextBoxColumn1
        '
        Me.DataGridViewTextBoxColumn1.DataPropertyName = "date"
        Me.DataGridViewTextBoxColumn1.HeaderText = "date"
        Me.DataGridViewTextBoxColumn1.Name = "DataGridViewTextBoxColumn1"
        '
        'DataGridViewTextBoxColumn2
        '
        Me.DataGridViewTextBoxColumn2.DataPropertyName = "time"
        Me.DataGridViewTextBoxColumn2.HeaderText = "time"
        Me.DataGridViewTextBoxColumn2.Name = "DataGridViewTextBoxColumn2"
        '
        'VenueDataGridViewTextBoxColumn
        '
        Me.VenueDataGridViewTextBoxColumn.DataPropertyName = "venue"
        Me.VenueDataGridViewTextBoxColumn.HeaderText = "venue"
        Me.VenueDataGridViewTextBoxColumn.Name = "VenueDataGridViewTextBoxColumn"
        '
        'Interselectview
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackgroundImage = CType(resources.GetObject("$this.BackgroundImage"), System.Drawing.Image)
        Me.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.ClientSize = New System.Drawing.Size(644, 551)
        Me.Controls.Add(Me.Button2)
        Me.Controls.Add(Me.Label5)
        Me.Controls.Add(Me.TextBox1)
        Me.Controls.Add(Me.MenuStrip1)
        Me.Controls.Add(Me.Label2)
        Me.Controls.Add(Me.Button1)
        Me.Controls.Add(Me.DataGridView1)
        Me.Controls.Add(Me.Button5)
        Me.Controls.Add(Me.Label1)
        Me.Name = "Interselectview"
        Me.Text = "Interselectview"
        CType(Me.DataGridView1, System.ComponentModel.ISupportInitialize).EndInit()
        Me.MenuStrip1.ResumeLayout(False)
        Me.MenuStrip1.PerformLayout()
        CType(Me.PssDataSet, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.InterDetailsBindingSource, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents Button5 As System.Windows.Forms.Button
    Friend WithEvents Label1 As System.Windows.Forms.Label
    Friend WithEvents DataGridView1 As System.Windows.Forms.DataGridView
    Friend WithEvents Button1 As System.Windows.Forms.Button
    Friend WithEvents Label2 As System.Windows.Forms.Label
    Friend WithEvents MenuStrip1 As System.Windows.Forms.MenuStrip
    Friend WithEvents ExitToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents STUDENTDETAILSToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents INSERTToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents UPDATEToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents DELETEToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents VIEWToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents INTERVIEWDETAILSToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents INSERTToolStripMenuItem1 As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents UPDATEToolStripMenuItem1 As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents DELETEToolStripMenuItem1 As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents VIEWToolStripMenuItem1 As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents PLACEMENTDETAILSToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents INSERTToolStripMenuItem2 As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents UPDATEToolStripMenuItem2 As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents DELETEToolStripMenuItem2 As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents VIEWToolStripMenuItem2 As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents COMPANYDETAILSToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents INSERTToolStripMenuItem3 As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents UPDATEToolStripMenuItem3 As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents DELETEToolStripMenuItem3 As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents VIEWToolStripMenuItem3 As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents REPORTGENERATIONToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents DEPATMENTREPORTToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents MAILTHEDATASToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents SettingsToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents ChangePasswordToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents LogOutToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents AddANewUserToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents EXITToolStripMenuItem1 As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents Button2 As System.Windows.Forms.Button
    Friend WithEvents Label5 As System.Windows.Forms.Label
    Friend WithEvents TextBox1 As System.Windows.Forms.TextBox
    Friend WithEvents SaveFileDialog1 As System.Windows.Forms.SaveFileDialog
    Friend WithEvents SENDTHESMSToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents DateDataGridViewTextBoxColumn As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents TimeDataGridViewTextBoxColumn As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents DateandtimeDataGridViewTextBoxColumn As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents PssDataSet As PSS.PssDataSet
    Friend WithEvents InterDetailsBindingSource As System.Windows.Forms.BindingSource
    Friend WithEvents InterDetailsTableAdapter As PSS.PssDataSetTableAdapters.InterDetailsTableAdapter
    Friend WithEvents CompanynameDataGridViewTextBoxColumn As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents AddressDataGridViewTextBoxColumn As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents DataGridViewTextBoxColumn1 As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents DataGridViewTextBoxColumn2 As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents VenueDataGridViewTextBoxColumn As System.Windows.Forms.DataGridViewTextBoxColumn
End Class
