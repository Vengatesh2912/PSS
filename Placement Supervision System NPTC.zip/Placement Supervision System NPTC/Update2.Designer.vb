﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Update2
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(Update2))
        Me.Button3 = New System.Windows.Forms.Button()
        Me.Label13 = New System.Windows.Forms.Label()
        Me.Button1 = New System.Windows.Forms.Button()
        Me.TextBox11 = New System.Windows.Forms.TextBox()
        Me.Label15 = New System.Windows.Forms.Label()
        Me.TextBox10 = New System.Windows.Forms.TextBox()
        Me.TextBox9 = New System.Windows.Forms.TextBox()
        Me.TextBox8 = New System.Windows.Forms.TextBox()
        Me.TextBox6 = New System.Windows.Forms.TextBox()
        Me.TextBox5 = New System.Windows.Forms.TextBox()
        Me.TextBox4 = New System.Windows.Forms.TextBox()
        Me.TextBox3 = New System.Windows.Forms.TextBox()
        Me.TextBox2 = New System.Windows.Forms.TextBox()
        Me.TextBox1 = New System.Windows.Forms.TextBox()
        Me.Label12 = New System.Windows.Forms.Label()
        Me.Label11 = New System.Windows.Forms.Label()
        Me.Label10 = New System.Windows.Forms.Label()
        Me.Label9 = New System.Windows.Forms.Label()
        Me.Label8 = New System.Windows.Forms.Label()
        Me.Label7 = New System.Windows.Forms.Label()
        Me.Label6 = New System.Windows.Forms.Label()
        Me.Label5 = New System.Windows.Forms.Label()
        Me.Label4 = New System.Windows.Forms.Label()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.Label14 = New System.Windows.Forms.Label()
        Me.MenuStrip1 = New System.Windows.Forms.MenuStrip()
        Me.ExitToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.STUDENTDETAILSToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.INSERTToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.UPDATEToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.DELETEToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.VIEWToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.INTERVIEWDETAILSToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.INSERTToolStripMenuItem1 = New System.Windows.Forms.ToolStripMenuItem()
        Me.UPDATEToolStripMenuItem1 = New System.Windows.Forms.ToolStripMenuItem()
        Me.DELETEToolStripMenuItem1 = New System.Windows.Forms.ToolStripMenuItem()
        Me.VIEWToolStripMenuItem1 = New System.Windows.Forms.ToolStripMenuItem()
        Me.PLACEMENTDETAILSToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.INSERTToolStripMenuItem2 = New System.Windows.Forms.ToolStripMenuItem()
        Me.UPDATEToolStripMenuItem2 = New System.Windows.Forms.ToolStripMenuItem()
        Me.DELETEToolStripMenuItem2 = New System.Windows.Forms.ToolStripMenuItem()
        Me.VIEWToolStripMenuItem2 = New System.Windows.Forms.ToolStripMenuItem()
        Me.COMPANYDETAILSToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.INSERTToolStripMenuItem3 = New System.Windows.Forms.ToolStripMenuItem()
        Me.UPDATEToolStripMenuItem3 = New System.Windows.Forms.ToolStripMenuItem()
        Me.DELETEToolStripMenuItem3 = New System.Windows.Forms.ToolStripMenuItem()
        Me.VIEWToolStripMenuItem3 = New System.Windows.Forms.ToolStripMenuItem()
        Me.REPORTGENERATIONToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.DEPATMENTREPORTToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.MAILTHEDATASToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.SENDTHESMSToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.SettingsToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.ChangePasswordToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.LogOutToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.AddANewUserToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.EXITToolStripMenuItem1 = New System.Windows.Forms.ToolStripMenuItem()
        Me.ComboBox1 = New System.Windows.Forms.ComboBox()
        Me.Label16 = New System.Windows.Forms.Label()
        Me.ComboBox2 = New System.Windows.Forms.ComboBox()
        Me.MenuStrip1.SuspendLayout()
        Me.SuspendLayout()
        '
        'Button3
        '
        Me.Button3.Location = New System.Drawing.Point(637, 36)
        Me.Button3.Name = "Button3"
        Me.Button3.Size = New System.Drawing.Size(68, 23)
        Me.Button3.TabIndex = 102
        Me.Button3.Text = "Back"
        Me.Button3.UseVisualStyleBackColor = True
        '
        'Label13
        '
        Me.Label13.AutoSize = True
        Me.Label13.BackColor = System.Drawing.Color.Transparent
        Me.Label13.Location = New System.Drawing.Point(238, 74)
        Me.Label13.Name = "Label13"
        Me.Label13.Size = New System.Drawing.Size(225, 13)
        Me.Label13.TabIndex = 100
        Me.Label13.Text = "PLACEMENT SUPERVISION SYSTEM (PSS)"
        '
        'Button1
        '
        Me.Button1.Location = New System.Drawing.Point(317, 414)
        Me.Button1.Name = "Button1"
        Me.Button1.Size = New System.Drawing.Size(75, 23)
        Me.Button1.TabIndex = 99
        Me.Button1.Text = "Update"
        Me.Button1.UseVisualStyleBackColor = True
        '
        'TextBox11
        '
        Me.TextBox11.Location = New System.Drawing.Point(548, 339)
        Me.TextBox11.Name = "TextBox11"
        Me.TextBox11.Size = New System.Drawing.Size(100, 20)
        Me.TextBox11.TabIndex = 126
        '
        'Label15
        '
        Me.Label15.AutoSize = True
        Me.Label15.BackColor = System.Drawing.Color.Transparent
        Me.Label15.Location = New System.Drawing.Point(395, 342)
        Me.Label15.Name = "Label15"
        Me.Label15.Size = New System.Drawing.Size(93, 13)
        Me.Label15.TabIndex = 125
        Me.Label15.Text = "Placed Company :"
        '
        'TextBox10
        '
        Me.TextBox10.Location = New System.Drawing.Point(548, 313)
        Me.TextBox10.Name = "TextBox10"
        Me.TextBox10.Size = New System.Drawing.Size(100, 20)
        Me.TextBox10.TabIndex = 123
        '
        'TextBox9
        '
        Me.TextBox9.Location = New System.Drawing.Point(548, 287)
        Me.TextBox9.Name = "TextBox9"
        Me.TextBox9.Size = New System.Drawing.Size(100, 20)
        Me.TextBox9.TabIndex = 122
        '
        'TextBox8
        '
        Me.TextBox8.Location = New System.Drawing.Point(548, 261)
        Me.TextBox8.Name = "TextBox8"
        Me.TextBox8.Size = New System.Drawing.Size(100, 20)
        Me.TextBox8.TabIndex = 121
        '
        'TextBox6
        '
        Me.TextBox6.Location = New System.Drawing.Point(548, 209)
        Me.TextBox6.Name = "TextBox6"
        Me.TextBox6.Size = New System.Drawing.Size(100, 20)
        Me.TextBox6.TabIndex = 120
        '
        'TextBox5
        '
        Me.TextBox5.Location = New System.Drawing.Point(142, 328)
        Me.TextBox5.Name = "TextBox5"
        Me.TextBox5.Size = New System.Drawing.Size(100, 20)
        Me.TextBox5.TabIndex = 119
        '
        'TextBox4
        '
        Me.TextBox4.Location = New System.Drawing.Point(142, 299)
        Me.TextBox4.Name = "TextBox4"
        Me.TextBox4.Size = New System.Drawing.Size(100, 20)
        Me.TextBox4.TabIndex = 118
        '
        'TextBox3
        '
        Me.TextBox3.Location = New System.Drawing.Point(142, 269)
        Me.TextBox3.Name = "TextBox3"
        Me.TextBox3.Size = New System.Drawing.Size(100, 20)
        Me.TextBox3.TabIndex = 117
        '
        'TextBox2
        '
        Me.TextBox2.Location = New System.Drawing.Point(142, 239)
        Me.TextBox2.Name = "TextBox2"
        Me.TextBox2.Size = New System.Drawing.Size(100, 20)
        Me.TextBox2.TabIndex = 116
        '
        'TextBox1
        '
        Me.TextBox1.Location = New System.Drawing.Point(142, 209)
        Me.TextBox1.Name = "TextBox1"
        Me.TextBox1.Size = New System.Drawing.Size(100, 20)
        Me.TextBox1.TabIndex = 115
        '
        'Label12
        '
        Me.Label12.AutoSize = True
        Me.Label12.BackColor = System.Drawing.Color.Transparent
        Me.Label12.Location = New System.Drawing.Point(395, 316)
        Me.Label12.Name = "Label12"
        Me.Label12.Size = New System.Drawing.Size(109, 13)
        Me.Label12.TabIndex = 114
        Me.Label12.Text = "Diploma Percentage :"
        '
        'Label11
        '
        Me.Label11.AutoSize = True
        Me.Label11.BackColor = System.Drawing.Color.Transparent
        Me.Label11.Location = New System.Drawing.Point(395, 290)
        Me.Label11.Name = "Label11"
        Me.Label11.Size = New System.Drawing.Size(135, 13)
        Me.Label11.TabIndex = 113
        Me.Label11.Text = "SSLC or HSC Percentage :"
        '
        'Label10
        '
        Me.Label10.AutoSize = True
        Me.Label10.BackColor = System.Drawing.Color.Transparent
        Me.Label10.Location = New System.Drawing.Point(395, 261)
        Me.Label10.Name = "Label10"
        Me.Label10.Size = New System.Drawing.Size(35, 13)
        Me.Label10.TabIndex = 112
        Me.Label10.Text = "Year :"
        '
        'Label9
        '
        Me.Label9.AutoSize = True
        Me.Label9.BackColor = System.Drawing.Color.Transparent
        Me.Label9.Location = New System.Drawing.Point(395, 237)
        Me.Label9.Name = "Label9"
        Me.Label9.Size = New System.Drawing.Size(68, 13)
        Me.Label9.TabIndex = 111
        Me.Label9.Text = "Department :"
        '
        'Label8
        '
        Me.Label8.AutoSize = True
        Me.Label8.BackColor = System.Drawing.Color.Transparent
        Me.Label8.Location = New System.Drawing.Point(395, 212)
        Me.Label8.Name = "Label8"
        Me.Label8.Size = New System.Drawing.Size(43, 13)
        Me.Label8.TabIndex = 110
        Me.Label8.Text = "Roll no:"
        '
        'Label7
        '
        Me.Label7.AutoSize = True
        Me.Label7.BackColor = System.Drawing.Color.Transparent
        Me.Label7.Location = New System.Drawing.Point(51, 331)
        Me.Label7.Name = "Label7"
        Me.Label7.Size = New System.Drawing.Size(26, 13)
        Me.Label7.TabIndex = 109
        Me.Label7.Text = "Age"
        '
        'Label6
        '
        Me.Label6.AutoSize = True
        Me.Label6.BackColor = System.Drawing.Color.Transparent
        Me.Label6.Location = New System.Drawing.Point(51, 302)
        Me.Label6.Name = "Label6"
        Me.Label6.Size = New System.Drawing.Size(53, 13)
        Me.Label6.TabIndex = 108
        Me.Label6.Text = "E-Mail ID:"
        '
        'Label5
        '
        Me.Label5.AutoSize = True
        Me.Label5.BackColor = System.Drawing.Color.Transparent
        Me.Label5.Location = New System.Drawing.Point(51, 272)
        Me.Label5.Name = "Label5"
        Me.Label5.Size = New System.Drawing.Size(56, 13)
        Me.Label5.TabIndex = 107
        Me.Label5.Text = "Phone no:"
        '
        'Label4
        '
        Me.Label4.AutoSize = True
        Me.Label4.BackColor = System.Drawing.Color.Transparent
        Me.Label4.Location = New System.Drawing.Point(51, 242)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(48, 13)
        Me.Label4.TabIndex = 106
        Me.Label4.Text = "Address:"
        '
        'Label3
        '
        Me.Label3.AutoSize = True
        Me.Label3.BackColor = System.Drawing.Color.Transparent
        Me.Label3.Location = New System.Drawing.Point(51, 212)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(38, 13)
        Me.Label3.TabIndex = 105
        Me.Label3.Text = "Name:"
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.BackColor = System.Drawing.Color.Transparent
        Me.Label2.Location = New System.Drawing.Point(524, 166)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(101, 13)
        Me.Label2.TabIndex = 104
        Me.Label2.Text = "OFFICIAL DETAILS"
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.BackColor = System.Drawing.Color.Transparent
        Me.Label1.Location = New System.Drawing.Point(107, 166)
        Me.Label1.Name = "Label1"
        Me.Label1.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.Label1.Size = New System.Drawing.Size(113, 13)
        Me.Label1.TabIndex = 103
        Me.Label1.Text = "PERSONAL DETAILS"
        '
        'Label14
        '
        Me.Label14.AutoSize = True
        Me.Label14.BackColor = System.Drawing.Color.Transparent
        Me.Label14.Location = New System.Drawing.Point(284, 113)
        Me.Label14.Name = "Label14"
        Me.Label14.Size = New System.Drawing.Size(135, 13)
        Me.Label14.TabIndex = 127
        Me.Label14.Text = "Update the Student Details"
        '
        'MenuStrip1
        '
        Me.MenuStrip1.Items.AddRange(New System.Windows.Forms.ToolStripItem() {Me.ExitToolStripMenuItem, Me.SettingsToolStripMenuItem, Me.EXITToolStripMenuItem1})
        Me.MenuStrip1.Location = New System.Drawing.Point(0, 0)
        Me.MenuStrip1.Name = "MenuStrip1"
        Me.MenuStrip1.Size = New System.Drawing.Size(727, 24)
        Me.MenuStrip1.TabIndex = 128
        Me.MenuStrip1.Text = "MenuStrip1"
        '
        'ExitToolStripMenuItem
        '
        Me.ExitToolStripMenuItem.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.STUDENTDETAILSToolStripMenuItem, Me.INTERVIEWDETAILSToolStripMenuItem, Me.PLACEMENTDETAILSToolStripMenuItem, Me.COMPANYDETAILSToolStripMenuItem, Me.REPORTGENERATIONToolStripMenuItem, Me.MAILTHEDATASToolStripMenuItem, Me.SENDTHESMSToolStripMenuItem})
        Me.ExitToolStripMenuItem.Name = "ExitToolStripMenuItem"
        Me.ExitToolStripMenuItem.Size = New System.Drawing.Size(70, 20)
        Me.ExitToolStripMenuItem.Text = "Go To >>"
        '
        'STUDENTDETAILSToolStripMenuItem
        '
        Me.STUDENTDETAILSToolStripMenuItem.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.INSERTToolStripMenuItem, Me.UPDATEToolStripMenuItem, Me.DELETEToolStripMenuItem, Me.VIEWToolStripMenuItem})
        Me.STUDENTDETAILSToolStripMenuItem.Name = "STUDENTDETAILSToolStripMenuItem"
        Me.STUDENTDETAILSToolStripMenuItem.Size = New System.Drawing.Size(192, 22)
        Me.STUDENTDETAILSToolStripMenuItem.Text = "STUDENT DETAILS"
        '
        'INSERTToolStripMenuItem
        '
        Me.INSERTToolStripMenuItem.Name = "INSERTToolStripMenuItem"
        Me.INSERTToolStripMenuItem.Size = New System.Drawing.Size(118, 22)
        Me.INSERTToolStripMenuItem.Text = "INSERT"
        '
        'UPDATEToolStripMenuItem
        '
        Me.UPDATEToolStripMenuItem.Name = "UPDATEToolStripMenuItem"
        Me.UPDATEToolStripMenuItem.Size = New System.Drawing.Size(118, 22)
        Me.UPDATEToolStripMenuItem.Text = "UPDATE"
        '
        'DELETEToolStripMenuItem
        '
        Me.DELETEToolStripMenuItem.Name = "DELETEToolStripMenuItem"
        Me.DELETEToolStripMenuItem.Size = New System.Drawing.Size(118, 22)
        Me.DELETEToolStripMenuItem.Text = "DELETE"
        '
        'VIEWToolStripMenuItem
        '
        Me.VIEWToolStripMenuItem.Name = "VIEWToolStripMenuItem"
        Me.VIEWToolStripMenuItem.Size = New System.Drawing.Size(118, 22)
        Me.VIEWToolStripMenuItem.Text = "VIEW"
        '
        'INTERVIEWDETAILSToolStripMenuItem
        '
        Me.INTERVIEWDETAILSToolStripMenuItem.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.INSERTToolStripMenuItem1, Me.UPDATEToolStripMenuItem1, Me.DELETEToolStripMenuItem1, Me.VIEWToolStripMenuItem1})
        Me.INTERVIEWDETAILSToolStripMenuItem.Name = "INTERVIEWDETAILSToolStripMenuItem"
        Me.INTERVIEWDETAILSToolStripMenuItem.Size = New System.Drawing.Size(192, 22)
        Me.INTERVIEWDETAILSToolStripMenuItem.Text = "INTERVIEW DETAILS"
        '
        'INSERTToolStripMenuItem1
        '
        Me.INSERTToolStripMenuItem1.Name = "INSERTToolStripMenuItem1"
        Me.INSERTToolStripMenuItem1.Size = New System.Drawing.Size(118, 22)
        Me.INSERTToolStripMenuItem1.Text = "INSERT"
        '
        'UPDATEToolStripMenuItem1
        '
        Me.UPDATEToolStripMenuItem1.Name = "UPDATEToolStripMenuItem1"
        Me.UPDATEToolStripMenuItem1.Size = New System.Drawing.Size(118, 22)
        Me.UPDATEToolStripMenuItem1.Text = "UPDATE"
        '
        'DELETEToolStripMenuItem1
        '
        Me.DELETEToolStripMenuItem1.Name = "DELETEToolStripMenuItem1"
        Me.DELETEToolStripMenuItem1.Size = New System.Drawing.Size(118, 22)
        Me.DELETEToolStripMenuItem1.Text = "DELETE"
        '
        'VIEWToolStripMenuItem1
        '
        Me.VIEWToolStripMenuItem1.Name = "VIEWToolStripMenuItem1"
        Me.VIEWToolStripMenuItem1.Size = New System.Drawing.Size(118, 22)
        Me.VIEWToolStripMenuItem1.Text = "VIEW"
        '
        'PLACEMENTDETAILSToolStripMenuItem
        '
        Me.PLACEMENTDETAILSToolStripMenuItem.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.INSERTToolStripMenuItem2, Me.UPDATEToolStripMenuItem2, Me.DELETEToolStripMenuItem2, Me.VIEWToolStripMenuItem2})
        Me.PLACEMENTDETAILSToolStripMenuItem.Name = "PLACEMENTDETAILSToolStripMenuItem"
        Me.PLACEMENTDETAILSToolStripMenuItem.Size = New System.Drawing.Size(192, 22)
        Me.PLACEMENTDETAILSToolStripMenuItem.Text = "PLACEMENT DETAILS"
        '
        'INSERTToolStripMenuItem2
        '
        Me.INSERTToolStripMenuItem2.Name = "INSERTToolStripMenuItem2"
        Me.INSERTToolStripMenuItem2.Size = New System.Drawing.Size(118, 22)
        Me.INSERTToolStripMenuItem2.Text = "INSERT"
        '
        'UPDATEToolStripMenuItem2
        '
        Me.UPDATEToolStripMenuItem2.Name = "UPDATEToolStripMenuItem2"
        Me.UPDATEToolStripMenuItem2.Size = New System.Drawing.Size(118, 22)
        Me.UPDATEToolStripMenuItem2.Text = "UPDATE"
        '
        'DELETEToolStripMenuItem2
        '
        Me.DELETEToolStripMenuItem2.Name = "DELETEToolStripMenuItem2"
        Me.DELETEToolStripMenuItem2.Size = New System.Drawing.Size(118, 22)
        Me.DELETEToolStripMenuItem2.Text = "DELETE"
        '
        'VIEWToolStripMenuItem2
        '
        Me.VIEWToolStripMenuItem2.Name = "VIEWToolStripMenuItem2"
        Me.VIEWToolStripMenuItem2.Size = New System.Drawing.Size(118, 22)
        Me.VIEWToolStripMenuItem2.Text = "VIEW"
        '
        'COMPANYDETAILSToolStripMenuItem
        '
        Me.COMPANYDETAILSToolStripMenuItem.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.INSERTToolStripMenuItem3, Me.UPDATEToolStripMenuItem3, Me.DELETEToolStripMenuItem3, Me.VIEWToolStripMenuItem3})
        Me.COMPANYDETAILSToolStripMenuItem.Name = "COMPANYDETAILSToolStripMenuItem"
        Me.COMPANYDETAILSToolStripMenuItem.Size = New System.Drawing.Size(192, 22)
        Me.COMPANYDETAILSToolStripMenuItem.Text = "COMPANY DETAILS"
        '
        'INSERTToolStripMenuItem3
        '
        Me.INSERTToolStripMenuItem3.Name = "INSERTToolStripMenuItem3"
        Me.INSERTToolStripMenuItem3.Size = New System.Drawing.Size(118, 22)
        Me.INSERTToolStripMenuItem3.Text = "INSERT"
        '
        'UPDATEToolStripMenuItem3
        '
        Me.UPDATEToolStripMenuItem3.Name = "UPDATEToolStripMenuItem3"
        Me.UPDATEToolStripMenuItem3.Size = New System.Drawing.Size(118, 22)
        Me.UPDATEToolStripMenuItem3.Text = "UPDATE"
        '
        'DELETEToolStripMenuItem3
        '
        Me.DELETEToolStripMenuItem3.Name = "DELETEToolStripMenuItem3"
        Me.DELETEToolStripMenuItem3.Size = New System.Drawing.Size(118, 22)
        Me.DELETEToolStripMenuItem3.Text = "DELETE"
        '
        'VIEWToolStripMenuItem3
        '
        Me.VIEWToolStripMenuItem3.Name = "VIEWToolStripMenuItem3"
        Me.VIEWToolStripMenuItem3.Size = New System.Drawing.Size(118, 22)
        Me.VIEWToolStripMenuItem3.Text = "VIEW"
        '
        'REPORTGENERATIONToolStripMenuItem
        '
        Me.REPORTGENERATIONToolStripMenuItem.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.DEPATMENTREPORTToolStripMenuItem})
        Me.REPORTGENERATIONToolStripMenuItem.Name = "REPORTGENERATIONToolStripMenuItem"
        Me.REPORTGENERATIONToolStripMenuItem.Size = New System.Drawing.Size(192, 22)
        Me.REPORTGENERATIONToolStripMenuItem.Text = "REPORT GENERATION"
        '
        'DEPATMENTREPORTToolStripMenuItem
        '
        Me.DEPATMENTREPORTToolStripMenuItem.Name = "DEPATMENTREPORTToolStripMenuItem"
        Me.DEPATMENTREPORTToolStripMenuItem.Size = New System.Drawing.Size(196, 22)
        Me.DEPATMENTREPORTToolStripMenuItem.Text = "DEPARTMENT REPORT"
        '
        'MAILTHEDATASToolStripMenuItem
        '
        Me.MAILTHEDATASToolStripMenuItem.Name = "MAILTHEDATASToolStripMenuItem"
        Me.MAILTHEDATASToolStripMenuItem.Size = New System.Drawing.Size(192, 22)
        Me.MAILTHEDATASToolStripMenuItem.Text = "SEND THE MAIL"
        '
        'SENDTHESMSToolStripMenuItem
        '
        Me.SENDTHESMSToolStripMenuItem.Name = "SENDTHESMSToolStripMenuItem"
        Me.SENDTHESMSToolStripMenuItem.Size = New System.Drawing.Size(192, 22)
        Me.SENDTHESMSToolStripMenuItem.Text = "SEND THE SMS"
        '
        'SettingsToolStripMenuItem
        '
        Me.SettingsToolStripMenuItem.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.ChangePasswordToolStripMenuItem, Me.LogOutToolStripMenuItem, Me.AddANewUserToolStripMenuItem})
        Me.SettingsToolStripMenuItem.Name = "SettingsToolStripMenuItem"
        Me.SettingsToolStripMenuItem.Size = New System.Drawing.Size(71, 20)
        Me.SettingsToolStripMenuItem.Text = "SETTINGS"
        '
        'ChangePasswordToolStripMenuItem
        '
        Me.ChangePasswordToolStripMenuItem.Name = "ChangePasswordToolStripMenuItem"
        Me.ChangePasswordToolStripMenuItem.Size = New System.Drawing.Size(168, 22)
        Me.ChangePasswordToolStripMenuItem.Text = "Change Password"
        '
        'LogOutToolStripMenuItem
        '
        Me.LogOutToolStripMenuItem.Name = "LogOutToolStripMenuItem"
        Me.LogOutToolStripMenuItem.Size = New System.Drawing.Size(168, 22)
        Me.LogOutToolStripMenuItem.Text = "Log Out"
        '
        'AddANewUserToolStripMenuItem
        '
        Me.AddANewUserToolStripMenuItem.Name = "AddANewUserToolStripMenuItem"
        Me.AddANewUserToolStripMenuItem.Size = New System.Drawing.Size(168, 22)
        Me.AddANewUserToolStripMenuItem.Text = "Add a New User"
        '
        'EXITToolStripMenuItem1
        '
        Me.EXITToolStripMenuItem1.Name = "EXITToolStripMenuItem1"
        Me.EXITToolStripMenuItem1.Size = New System.Drawing.Size(42, 20)
        Me.EXITToolStripMenuItem1.Text = "EXIT"
        '
        'ComboBox1
        '
        Me.ComboBox1.FormattingEnabled = True
        Me.ComboBox1.Items.AddRange(New Object() {"selected", "not selected"})
        Me.ComboBox1.Location = New System.Drawing.Point(298, 372)
        Me.ComboBox1.Name = "ComboBox1"
        Me.ComboBox1.Size = New System.Drawing.Size(121, 21)
        Me.ComboBox1.TabIndex = 130
        '
        'Label16
        '
        Me.Label16.AutoSize = True
        Me.Label16.BackColor = System.Drawing.Color.Transparent
        Me.Label16.Location = New System.Drawing.Point(211, 375)
        Me.Label16.Name = "Label16"
        Me.Label16.Size = New System.Drawing.Size(70, 13)
        Me.Label16.TabIndex = 129
        Me.Label16.Text = "Placed or not"
        '
        'ComboBox2
        '
        Me.ComboBox2.FormattingEnabled = True
        Me.ComboBox2.Items.AddRange(New Object() {"CT", "ECE", "ECE SF", "EEE", "EEE SF", "MECH", "MECH SF", "MECH SW", "MECH R&AC", "MECH TVS", "AUTO", "AUTO SF", "CIVIL", "CIVIL SF", "ICE", "PT", "TT"})
        Me.ComboBox2.Location = New System.Drawing.Point(548, 234)
        Me.ComboBox2.Name = "ComboBox2"
        Me.ComboBox2.Size = New System.Drawing.Size(100, 21)
        Me.ComboBox2.TabIndex = 131
        '
        'Update2
        '
        Me.AcceptButton = Me.Button1
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackgroundImage = CType(resources.GetObject("$this.BackgroundImage"), System.Drawing.Image)
        Me.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.ClientSize = New System.Drawing.Size(727, 465)
        Me.Controls.Add(Me.ComboBox2)
        Me.Controls.Add(Me.ComboBox1)
        Me.Controls.Add(Me.Label16)
        Me.Controls.Add(Me.MenuStrip1)
        Me.Controls.Add(Me.Label14)
        Me.Controls.Add(Me.TextBox11)
        Me.Controls.Add(Me.Label15)
        Me.Controls.Add(Me.TextBox10)
        Me.Controls.Add(Me.TextBox9)
        Me.Controls.Add(Me.TextBox8)
        Me.Controls.Add(Me.TextBox6)
        Me.Controls.Add(Me.TextBox5)
        Me.Controls.Add(Me.TextBox4)
        Me.Controls.Add(Me.TextBox3)
        Me.Controls.Add(Me.TextBox2)
        Me.Controls.Add(Me.TextBox1)
        Me.Controls.Add(Me.Label12)
        Me.Controls.Add(Me.Label11)
        Me.Controls.Add(Me.Label10)
        Me.Controls.Add(Me.Label9)
        Me.Controls.Add(Me.Label8)
        Me.Controls.Add(Me.Label7)
        Me.Controls.Add(Me.Label6)
        Me.Controls.Add(Me.Label5)
        Me.Controls.Add(Me.Label4)
        Me.Controls.Add(Me.Label3)
        Me.Controls.Add(Me.Label2)
        Me.Controls.Add(Me.Label1)
        Me.Controls.Add(Me.Button3)
        Me.Controls.Add(Me.Label13)
        Me.Controls.Add(Me.Button1)
        Me.Name = "Update2"
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
        Me.Text = "STUDENT DETAILS"
        Me.MenuStrip1.ResumeLayout(False)
        Me.MenuStrip1.PerformLayout()
        Me.ResumeLayout(False)
        Me.PerformLayout

End Sub
    Friend WithEvents Button3 As System.Windows.Forms.Button
    Friend WithEvents Label13 As System.Windows.Forms.Label
    Friend WithEvents Button1 As System.Windows.Forms.Button
    Friend WithEvents TextBox11 As System.Windows.Forms.TextBox
    Friend WithEvents Label15 As System.Windows.Forms.Label
    Friend WithEvents TextBox10 As System.Windows.Forms.TextBox
    Friend WithEvents TextBox9 As System.Windows.Forms.TextBox
    Friend WithEvents TextBox8 As System.Windows.Forms.TextBox
    Friend WithEvents TextBox6 As System.Windows.Forms.TextBox
    Friend WithEvents TextBox5 As System.Windows.Forms.TextBox
    Friend WithEvents TextBox4 As System.Windows.Forms.TextBox
    Friend WithEvents TextBox3 As System.Windows.Forms.TextBox
    Friend WithEvents TextBox2 As System.Windows.Forms.TextBox
    Friend WithEvents TextBox1 As System.Windows.Forms.TextBox
    Friend WithEvents Label12 As System.Windows.Forms.Label
    Friend WithEvents Label11 As System.Windows.Forms.Label
    Friend WithEvents Label10 As System.Windows.Forms.Label
    Friend WithEvents Label9 As System.Windows.Forms.Label
    Friend WithEvents Label8 As System.Windows.Forms.Label
    Friend WithEvents Label7 As System.Windows.Forms.Label
    Friend WithEvents Label6 As System.Windows.Forms.Label
    Friend WithEvents Label5 As System.Windows.Forms.Label
    Friend WithEvents Label4 As System.Windows.Forms.Label
    Friend WithEvents Label3 As System.Windows.Forms.Label
    Friend WithEvents Label2 As System.Windows.Forms.Label
    Public WithEvents Label1 As System.Windows.Forms.Label
    Friend WithEvents Label14 As System.Windows.Forms.Label
    Friend WithEvents MenuStrip1 As System.Windows.Forms.MenuStrip
    Friend WithEvents ExitToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents STUDENTDETAILSToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents INSERTToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents UPDATEToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents DELETEToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents VIEWToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents INTERVIEWDETAILSToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents INSERTToolStripMenuItem1 As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents UPDATEToolStripMenuItem1 As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents DELETEToolStripMenuItem1 As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents VIEWToolStripMenuItem1 As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents PLACEMENTDETAILSToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents INSERTToolStripMenuItem2 As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents UPDATEToolStripMenuItem2 As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents DELETEToolStripMenuItem2 As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents VIEWToolStripMenuItem2 As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents COMPANYDETAILSToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents INSERTToolStripMenuItem3 As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents UPDATEToolStripMenuItem3 As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents DELETEToolStripMenuItem3 As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents VIEWToolStripMenuItem3 As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents REPORTGENERATIONToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents DEPATMENTREPORTToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents MAILTHEDATASToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents SettingsToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents ChangePasswordToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents LogOutToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents AddANewUserToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents EXITToolStripMenuItem1 As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents ComboBox1 As System.Windows.Forms.ComboBox
    Friend WithEvents Label16 As System.Windows.Forms.Label
    Friend WithEvents SENDTHESMSToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents ComboBox2 As System.Windows.Forms.ComboBox
End Class
